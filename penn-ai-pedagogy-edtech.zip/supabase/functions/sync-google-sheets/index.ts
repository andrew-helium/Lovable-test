const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface TimelineItem {
  id: string;
  year: number;
  label: string;
  category: string;
  brief: string;
  detail: string;
  sources?: { label: string; url: string }[];
  imageUrl?: string;
  relatedTags?: string[];
  academicArticle?: { label: string; url: string };
  scholar?: string;
}

// Google Sheets API helpers
async function getAccessToken(serviceAccountJson: string): Promise<string> {
  // Handle potential double-stringified or escaped JSON
  let cleaned = serviceAccountJson.trim().replace(/^\uFEFF/, '');
  // If it starts with a quote, it may be double-stringified
  if (cleaned.startsWith('"') || cleaned.startsWith("'")) {
    try {
      cleaned = JSON.parse(cleaned);
    } catch {
      // strip surrounding quotes
      cleaned = cleaned.slice(1, -1).replace(/\\n/g, '\n').replace(/\\"/g, '"');
    }
  }
  const sa = typeof cleaned === 'string' ? JSON.parse(cleaned) : cleaned;
  const now = Math.floor(Date.now() / 1000);
  const header = btoa(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claim = btoa(JSON.stringify({
    iss: sa.client_email,
    scope: 'https://www.googleapis.com/auth/spreadsheets',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now,
  }));

  const signInput = `${header}.${claim}`;

  // Import the private key
  const pemContents = sa.private_key
    .replace(/-----BEGIN PRIVATE KEY-----/, '')
    .replace(/-----END PRIVATE KEY-----/, '')
    .replace(/\n/g, '');
  const binaryKey = Uint8Array.from(atob(pemContents), c => c.charCodeAt(0));

  const cryptoKey = await crypto.subtle.importKey(
    'pkcs8',
    binaryKey,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const signature = await crypto.subtle.sign(
    'RSASSA-PKCS1-v1_5',
    cryptoKey,
    new TextEncoder().encode(signInput)
  );

  const sig = btoa(String.fromCharCode(...new Uint8Array(signature)))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

  const jwt = `${signInput}.${sig}`;

  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });

  const tokenData = await tokenRes.json();
  if (!tokenRes.ok) {
    console.error('Google token exchange failed:', tokenData);
    throw new Error('Google authentication failed');
  }
  return tokenData.access_token;
}

// Base64url encode (no padding)
function base64url(str: string): string {
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function ensureSheetExists(accessToken: string, spreadsheetId: string, sheetName: string) {
  const baseUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`;
  const headers = { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' };

  // Get existing sheets
  const res = await fetch(`${baseUrl}?fields=sheets.properties.title`, { headers });
  const data = await res.json();
  const existing = (data.sheets || []).map((s: any) => s.properties.title);

  if (!existing.includes(sheetName)) {
    await fetch(`${baseUrl}:batchUpdate`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ requests: [{ addSheet: { properties: { title: sheetName } } }] }),
    });
    console.log(`Created sheet tab: ${sheetName}`);
  }
}

async function clearAndWriteSheet(
  accessToken: string,
  spreadsheetId: string,
  sheetName: string,
  rows: string[][]
) {
  await ensureSheetExists(accessToken, spreadsheetId, sheetName);

  const baseUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`;
  const range = `'${sheetName}'!A1:Z1000`;
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };

  await fetch(`${baseUrl}/values/${encodeURIComponent(range)}:clear`, { method: 'POST', headers });

  if (rows.length > 0) {
    const res = await fetch(`${baseUrl}/values/${encodeURIComponent(`'${sheetName}'!A1`)}?valueInputOption=RAW`, {
      method: 'PUT',
      headers,
      body: JSON.stringify({ values: rows }),
    });
    if (!res.ok) {
      const err = await res.text();
      console.error(`Write to ${sheetName} failed:`, err);
      throw new Error('Failed to write data');
    }
  }
}

async function appendRowToSheet(
  accessToken: string,
  spreadsheetId: string,
  sheetName: string,
  row: string[]
) {
  await ensureSheetExists(accessToken, spreadsheetId, sheetName);

  const baseUrl = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`;
  const range = `'${sheetName}'!A1`;
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };

  const res = await fetch(
    `${baseUrl}/values/${encodeURIComponent(range)}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
    {
      method: 'POST',
      headers,
      body: JSON.stringify({ values: [row] }),
    }
  );
  if (!res.ok) {
    const err = await res.text();
    console.error(`Append to ${sheetName} failed:`, err);
    throw new Error('Failed to append data');
  }
}

// Timeline data embedded
const timelineItems: TimelineItem[] = [
  // EDUCATIONAL TECHNOLOGIES
  { id: 'plato-system', year: 1960, label: 'PLATO', category: 'edtech', brief: 'One of the first computer-based education systems, pioneering online interaction.', detail: 'PLATO (Programmed Logic for Automatic Teaching Operations), developed at the University of Illinois starting in 1960, was one of the first generalized computer-assisted instruction systems.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6c/ENIAC_Penn1.jpg/440px-ENIAC_Penn1.jpg', relatedTags: ['Cognitivism', 'Behaviorism', 'Knowledge Distribution & Classification'], academicArticle: { label: 'Smith, S.G. & Sherwood, B.A. (1976). Educational Uses of the PLATO Computer System. Science.', url: 'https://doi.org/10.1126/science.192.4237.344' } },
  { id: 'textbook', year: 1800, label: 'Textbook', category: 'edtech', brief: 'Standardized textbooks become the backbone of formal instruction.', detail: 'Textbooks emerged as a dominant educational technology in the 18th–19th centuries.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/98/Textbooks.jpg/440px-Textbooks.jpg', relatedTags: ['Knowledge Distribution & Classification', 'Cognitivism'], academicArticle: { label: 'Wakefield, J. (1998). A Brief History of Textbooks.', url: 'https://doi.org/10.1080/00228958.1998.10518552' } },
  { id: 'overhead-projector', year: 1945, label: 'Overhead Projector', category: 'edtech', brief: 'Overhead projectors become standard classroom presentation tools.', detail: 'Originally developed for military training in WWII, overhead projectors became ubiquitous in classrooms.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/72/OHP-sch.JPG/440px-OHP-sch.JPG', relatedTags: ['Cognitive Overload', 'Behaviorism'], academicArticle: { label: 'Cuban, L. (1986). Teachers and Machines.', url: 'https://doi.org/10.1177/019263658707150122' } },
  { id: 'skinners-teaching-machine', year: 1958, label: "Skinner's Teaching Machine", category: 'edtech', brief: 'B.F. Skinner introduces programmed instruction via mechanical devices.', detail: "Skinner's teaching machines used operant conditioning principles.", imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/Skinner_teaching_machine_01.jpg/440px-Skinner_teaching_machine_01.jpg', relatedTags: ['Behaviorism', 'Cognitivism'], academicArticle: { label: 'Skinner, B.F. (1958). Teaching Machines. Science, 128(3330).', url: 'https://doi.org/10.1126/science.128.3330.969' } },
  { id: 'eliza', year: 1966, label: 'ELIZA', category: 'edtech', brief: 'Joseph Weizenbaum creates ELIZA, an early NLP program.', detail: 'ELIZA simulated conversation by pattern-matching user input.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/79/ELIZA_conversation.png/440px-ELIZA_conversation.png', relatedTags: ['Behaviorism', 'Cognitivism'], academicArticle: { label: 'Weizenbaum, J. (1966). ELIZA. Communications of the ACM, 9(1).', url: 'https://doi.org/10.1145/365153.365168' } },
  { id: 'seymour-papert-turtle', year: 1967, label: "Seymour Papert's Turtle", category: 'edtech', brief: 'Papert creates Logo and turtle graphics to teach children computational thinking.', detail: "Seymour Papert's Logo programming language embodied constructionist learning.", imageUrl: '/images/papert-turtle.png', relatedTags: ['Constructivism', 'Transfer of Learning'], academicArticle: { label: 'Papert, S. (1980). Mindstorms: Children, Computers, and Powerful Ideas.', url: 'https://doi.org/10.1007/978-3-0348-5357-6' } },
  { id: 'lms', year: 1982, label: 'Learning Management Systems', category: 'edtech', brief: 'LMS platforms digitize course management and content delivery.', detail: 'LMS like Blackboard and Moodle standardized digital course management.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/Syrian_refugee_children_in_a_Lebanese_school_classroom_%2815101234827%29.jpg/440px-Syrian_refugee_children_in_a_Lebanese_school_classroom_%2815101234827%29.jpg', relatedTags: ['Knowledge Distribution & Classification', 'Cognitive Overload'], academicArticle: { label: 'Coates, H. et al. (2005). A Critical Examination of LMS.', url: 'https://doi.org/10.1007/s11233-005-0131-7' } },
  { id: 'its', year: 1984, label: 'Intelligent Tutoring Systems', category: 'edtech', brief: 'ITS systems adapt instruction to individual learners using AI.', detail: "Anderson's LISP Tutor at CMU demonstrated AI-driven personalized instruction.", imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Interactive_whiteboard_at_CeBIT_2007.jpg/440px-Interactive_whiteboard_at_CeBIT_2007.jpg', relatedTags: ['Cognitivism', 'Cognitive Overload', 'Behaviorism'], academicArticle: { label: 'Anderson, J.R. et al. (1985). Intelligent Tutoring Systems. Science, 228(4698).', url: 'https://doi.org/10.1126/science.228.4698.456' } },
  { id: 'smart-whiteboard', year: 1991, label: 'Smart Interactive Whiteboard', category: 'edtech', brief: 'Interactive whiteboards bring touch-based digital displays to classrooms.', detail: 'Smart interactive whiteboards combined projection with touch sensitivity.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Interactive_whiteboard_at_CeBIT_2007.jpg/440px-Interactive_whiteboard_at_CeBIT_2007.jpg', relatedTags: ['Constructivism', 'Cognitive Overload'], academicArticle: { label: 'Higgins, S. et al. (2007). The Impact of Interactive Whiteboards.', url: 'https://doi.org/10.1080/01411920701243755' } },
  { id: 'discussion-forum', year: 1994, label: 'Online Discussion Forum', category: 'edtech', brief: 'Web-based forums enable asynchronous academic discussion.', detail: 'Online discussion forums extended classroom dialogue beyond physical walls.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/Phpbb_3.0_prosilver.png/440px-Phpbb_3.0_prosilver.png', relatedTags: ['Constructivism', 'Knowledge Distribution & Classification'], academicArticle: { label: 'Garrison, D.R. et al. (2000). Critical Inquiry in a Text-Based Environment.', url: 'https://doi.org/10.1016/S1096-7516(00)00016-6' } },
  { id: 'vr-ar', year: 1995, label: 'VR / AR', category: 'edtech', brief: 'VR and AR create immersive learning environments.', detail: 'VR and AR enable immersive, experiential learning.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/Reality_check_ESA384313.jpg/440px-Reality_check_ESA384313.jpg', relatedTags: ['Constructivism', 'Transfer of Learning', 'Cognitive Overload'], academicArticle: { label: 'Mikropoulos, T.A. & Natsis, A. (2011). Educational Virtual Environments.', url: 'https://doi.org/10.1016/j.compedu.2010.06.017' } },
  { id: 'virtual-classroom-tools', year: 1999, label: 'Virtual Classroom Tools', category: 'edtech', brief: 'Synchronous online tools enable real-time remote instruction.', detail: 'Virtual classroom tools like Zoom enabled synchronous online instruction.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Zoom_participants_Bubrikh_readings_2020_conference.png/440px-Zoom_participants_Bubrikh_readings_2020_conference.png', relatedTags: ['COVID-19 Pandemic', 'Shortened Distributed Attention'], academicArticle: { label: 'Martin, F. & Parker, M.A. (2014). Use of Synchronous Virtual Classrooms.', url: 'https://doi.org/10.1016/j.iheduc.2013.09.001' } },
  { id: 'scratch', year: 2007, label: 'Scratch', category: 'edtech', brief: "MIT's Scratch makes programming accessible to young learners.", detail: "Scratch provides a visual block-based programming environment.", imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/Scratch_editor_screenshot.png/440px-Scratch_editor_screenshot.png', relatedTags: ['Constructivism', 'Transfer of Learning'], academicArticle: { label: 'Resnick, M. et al. (2009). Scratch: Programming for All.', url: 'https://doi.org/10.1145/1592761.1592779' } },
  { id: 'khan-academy', year: 2008, label: 'Khan Academy', category: 'edtech', brief: 'Sal Khan launches a platform for free, world-class education.', detail: 'Khan Academy popularized the flipped classroom model.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d2/Salman_Khan_TED_2011.jpg/440px-Salman_Khan_TED_2011.jpg', relatedTags: ['Cognitivism', 'Knowledge Distribution & Classification'], academicArticle: { label: 'Thompson, C. (2011). How Khan Academy Is Changing the Rules of Education. Wired.', url: 'https://www.wired.com/2011/07/ff-khan/' } },
  { id: 'classdojo', year: 2011, label: 'ClassDojo', category: 'edtech', brief: 'ClassDojo connects teachers, students, and families.', detail: 'ClassDojo became one of the most widely used classroom management tools.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/Syrian_refugee_children_in_a_Lebanese_school_classroom_%2815101234827%29.jpg/440px-Syrian_refugee_children_in_a_Lebanese_school_classroom_%2815101234827%29.jpg', relatedTags: ['Behaviorism', 'Shortened Distributed Attention'], academicArticle: { label: 'Manolev, J. et al. (2019). Measuring Student Behaviour.', url: 'https://doi.org/10.1080/01425692.2018.1523505' } },
  { id: 'on-demand-platforms', year: 2012, label: 'On-Demand Platforms', category: 'edtech', brief: 'On-demand learning platforms bring courses to a global audience.', detail: 'Platforms like Coursera and edX brought structured education to millions.', imageUrl: 'https://upload.wikimedia.org/wikipedia/en/thumb/8/8f/Coursera_homepage.png/440px-Coursera_homepage.png', relatedTags: ['Knowledge Distribution & Classification', 'Transfer of Learning'], academicArticle: { label: 'Jordan, K. (2014). Initial Trends in MOOC Enrolment and Completion.', url: 'https://doi.org/10.19173/irrodl.v15i1.1651' } },
  { id: 'theseus', year: 1950, label: 'Theseus', category: 'edtech', brief: 'Claude Shannon builds Theseus, a mechanical mouse that learns to navigate a maze.', detail: 'Theseus was one of the earliest demonstrations of machine learning and AI.', imageUrl: '/images/theseus.png', relatedTags: ['Cognitivism', 'Connectionism', 'Behaviorism'], academicArticle: { label: 'Shannon, C.E. (1952). Presentation of a Maze-Solving Machine.', url: 'https://doi.org/10.1037/13272-028' } },
  { id: 'chatgpt', year: 2022, label: 'ChatGPT', category: 'edtech', brief: 'ChatGPT reaches 100 million users in 2 months, disrupting education.', detail: 'ChatGPT made conversational AI accessible to everyone.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/66/OpenAI_logo_2025_%28symbol%29.svg/440px-OpenAI_logo_2025_%28symbol%29.svg.png', relatedTags: ['Connectionism', 'Cognitive Overload', 'Transfer of Learning'], academicArticle: { label: 'Baidoo-Anu, D. & Ansah, L.O. (2023). Education in the Era of Generative AI.', url: 'https://doi.org/10.69554/JAIWA.02.01.0007' } },
  { id: 'llm', year: 2023, label: 'Large Language Models', category: 'edtech', brief: 'LLMs like GPT-4, Claude, and Gemini advance multimodal AI.', detail: 'The proliferation of powerful LLMs created a competitive AI ecosystem.', imageUrl: 'https://upload.wikimedia.org/wikipedia/en/a/a1/GPT-4_icon.png', relatedTags: ['Connectionism', 'Shortened Distributed Attention', 'COVID-19 Pandemic'], academicArticle: { label: 'Kasneci, E. et al. (2023). ChatGPT for Good?', url: 'https://doi.org/10.1016/j.lindif.2023.102274' } },
  { id: 'notebooklm', year: 2023, label: 'NotebookLM', category: 'edtech', brief: "Google's NotebookLM provides AI-powered research assistance.", detail: 'NotebookLM uses LLMs to help users analyze and summarize documents.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9b/Google_Gemini_Screenshot_%282026%29.png/440px-Google_Gemini_Screenshot_%282026%29.png', relatedTags: ['Cognitivism', 'Cognitive Overload', 'Knowledge Distribution & Classification'], academicArticle: { label: 'Mollick, E. & Mollick, L. (2023). Using AI to Implement Effective Teaching Strategies.', url: 'https://doi.org/10.2139/ssrn.4391243' } },
  { id: 'open-claw', year: 2025, label: 'Open Claw', category: 'edtech', brief: 'Open Claw explores open-source AI tools for education.', detail: 'Open Claw represents the emerging wave of open-source AI frameworks for educators.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Debian_13_with_FOSS_software_open.png/440px-Debian_13_with_FOSS_software_open.png', relatedTags: ['Connectionism', 'Knowledge Distribution & Classification'], academicArticle: { label: 'Miao, F. et al. (2021). AI and Education. UNESCO.', url: 'https://unesdoc.unesco.org/ark:/48223/pf0000376709' } },

  // GENERAL TECHNOLOGIES
  { id: 'radio', year: 1920, label: 'Radio', category: 'gentech', brief: 'Radio broadcasting brings information into homes at scale.', detail: 'Commercial radio became a tool for mass communication and education.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Radio_News_Sep_1928_Cover.jpg/440px-Radio_News_Sep_1928_Cover.jpg', relatedTags: ['Knowledge Distribution & Classification', 'Behaviorism'], academicArticle: { label: 'Cuban, L. (1986). Teachers and Machines.', url: 'https://doi.org/10.1177/019263658707150122' } },
  { id: 'writing', year: 1800, label: 'Writing', category: 'gentech', brief: 'Writing systems enable recording and transmitting knowledge.', detail: 'Writing was the first technology to externalize human memory.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/Xerxes_Cuneiform_Van.JPG/440px-Xerxes_Cuneiform_Van.JPG', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Ong, W. (1982). Orality and Literacy.', url: 'https://doi.org/10.4324/9780203328064' } },
  { id: 'printing-press', year: 1800, label: 'Printing Press', category: 'gentech', brief: "Gutenberg's printing press democratizes written knowledge.", detail: 'The printing press made books affordable and widespread.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/PrintMus_038.jpg/440px-PrintMus_038.jpg', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Eisenstein, E. (1979). The Printing Press as an Agent of Change.', url: 'https://doi.org/10.1017/CBO9781107049963' } },
  { id: 'glasses', year: 1800, label: 'Glasses', category: 'gentech', brief: 'Corrective lenses extend productive life for scholars.', detail: 'Eyeglasses were among the first technologies to augment human capability.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/2023_Okulary_korekcyjne.jpg/440px-2023_Okulary_korekcyjne.jpg', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Ilardi, V. (2007). Renaissance Vision from Spectacles to Telescopes.', url: 'https://doi.org/10.1090/mbk/259' } },
  { id: 'microscope', year: 1800, label: 'Microscope', category: 'gentech', brief: 'The microscope reveals the invisible world.', detail: 'The microscope opened entirely new fields of scientific inquiry.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/Ukrainian_microscope_%28cropped%29.jpg/440px-Ukrainian_microscope_%28cropped%29.jpg', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Ford, B.J. (1985). Single Lens.', url: 'https://doi.org/10.1017/S0007087400025887' } },
  { id: 'steam-engine', year: 1800, label: 'Steam Engine', category: 'gentech', brief: 'The steam engine powers the Industrial Revolution.', detail: "Watt's improved steam engine drove the Industrial Revolution.", imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Steam_locomotive_gear_%28J%C5%BD_06-018%3B_Slovenia%29.jpg/440px-Steam_locomotive_gear_%28J%C5%BD_06-018%3B_Slovenia%29.jpg', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Mokyr, J. (1990). The Lever of Riches.', url: 'https://doi.org/10.1093/acprof:oso/9780195074772.001.0001' } },
  { id: 'steam-locomotive', year: 1804, label: 'Steam Locomotive', category: 'gentech', brief: 'Steam-powered rail transforms transportation.', detail: 'Richard Trevithick demonstrated the first steam locomotive in 1804.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5a/Number_4468_Mallard_in_York.jpg/440px-Number_4468_Mallard_in_York.jpg', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Freeman, M.J. (1999). Railways and the Victorian Imagination.', url: 'https://doi.org/10.12987/yale/9780300079920.001.0001' } },
  { id: 'photography', year: 1826, label: 'Photography', category: 'gentech', brief: 'Photography captures visual reality for the first time.', detail: 'Niépce produced the first photograph in 1826.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d2/Roger_Fenton%27s_waggon.jpg/440px-Roger_Fenton%27s_waggon.jpg', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Batchen, G. (1997). Burning with Desire.', url: 'https://doi.org/10.7551/mitpress/1692.001.0001' } },
  { id: 'telegraph', year: 1837, label: 'Telegraph', category: 'gentech', brief: 'The telegraph enables instant long-distance communication.', detail: "Morse's telegraph separated communication from transportation.", imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Cooke_and_Wheatstone_electric_telegraph.jpg/440px-Cooke_and_Wheatstone_electric_telegraph.jpg', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Standage, T. (1998). The Victorian Internet.', url: 'https://doi.org/10.5860/choice.36-2524' } },
  { id: 'telephone', year: 1876, label: 'Telephone', category: 'gentech', brief: 'Bell patents the telephone.', detail: 'The telephone enabled real-time voice communication.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a6/Telefon_BW_2012-02-18_13-44-32.JPG/440px-Telefon_BW_2012-02-18_13-44-32.JPG', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Fischer, C.S. (1992). America Calling.', url: 'https://doi.org/10.1525/9780520911222' } },
  { id: 'electric-light', year: 1879, label: 'Electric Light', category: 'gentech', brief: "Edison's light bulb transforms daily life.", detail: "Edison's light bulb extended productive hours.", imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b4/Gluehlampe_01_KMJ.png/440px-Gluehlampe_01_KMJ.png', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Nye, D.E. (1990). Electrifying America.', url: 'https://doi.org/10.7551/mitpress/2726.001.0001' } },
  { id: 'automobile', year: 1886, label: 'Automobile', category: 'gentech', brief: 'Benz patents the first practical automobile.', detail: 'The automobile transformed geography and social organization.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/1925_Ford_Model_T_touring.jpg/440px-1925_Ford_Model_T_touring.jpg', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Rae, J.B. (1965). The American Automobile.', url: 'https://doi.org/10.7208/chicago/9780226707860.001.0001' } },
  { id: 'wright-brothers', year: 1903, label: 'Airplane', category: 'gentech', brief: 'The Wright Brothers achieve powered flight.', detail: "The Wright Brothers' 1903 flight inaugurated aviation.", imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/First_flight2.jpg/440px-First_flight2.jpg', relatedTags: ['Transfer of Learning'], academicArticle: { label: "Crouch, T.D. (2003). The Bishop's Boys.", url: 'https://doi.org/10.1017/S0003598X00062128' } },
  { id: 'television', year: 1927, label: 'Television', category: 'gentech', brief: 'Television brings moving images into homes worldwide.', detail: 'Television became the dominant mass medium of the 20th century.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Cptvdisplay.jpg/440px-Cptvdisplay.jpg', relatedTags: ['Shortened Distributed Attention', 'Knowledge Distribution & Classification'], academicArticle: { label: 'Postman, N. (1985). Amusing Ourselves to Death.', url: 'https://doi.org/10.1075/babel.32.1.14bou' } },
  { id: 'eeg', year: 1929, label: 'EEG', category: 'gentech', brief: 'Hans Berger records the first human EEG.', detail: 'EEG allowed measuring electrical brain activity for the first time.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Spike-waves.png/440px-Spike-waves.png', relatedTags: ['Cognitivism', 'Behaviorism'], academicArticle: { label: 'Berger, H. (1929). Über das Elektrenkephalogramm des Menschen.', url: 'https://doi.org/10.1007/BF01797193' } },
  { id: 'turing-machine', year: 1936, label: 'Turing Machine', category: 'gentech', brief: 'Turing proposes a theoretical machine capable of any computation.', detail: 'The Turing machine established the theoretical foundation for all modern computing.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Alan_turing_header.jpg/440px-Alan_turing_header.jpg', relatedTags: ['Cognitivism', 'Connectionism'], academicArticle: { label: 'Turing, A.M. (1936). On Computable Numbers.', url: 'https://doi.org/10.1112/plms/s2-42.1.230' } },
  { id: 'cybernetics', year: 1948, label: 'Cybernetics', category: 'gentech', brief: 'Wiener founds cybernetics.', detail: 'Cybernetics established the framework for feedback loops in machines and organisms.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/Norbert_Wiener.png/440px-Norbert_Wiener.png', relatedTags: ['Cognitivism', 'Connectionism'], academicArticle: { label: 'Wiener, N. (1948). Cybernetics.', url: 'https://doi.org/10.1002/j.2333-8504.1950.tb00013.x' } },
  { id: 'discovery-dna', year: 1953, label: 'Discovery of DNA', category: 'gentech', brief: 'Watson and Crick reveal the double helix structure.', detail: 'The 1953 discovery launched molecular biology.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d0/Chromosome_DNA_Gene_unlabeled.png/440px-Chromosome_DNA_Gene_unlabeled.png', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Watson, J.D. & Crick, F.H.C. (1953). Molecular Structure of Nucleic Acids.', url: 'https://doi.org/10.1038/171737a0' } },
  { id: 'computer-system', year: 1960, label: 'Computer System', category: 'gentech', brief: 'Mainframe computers enter universities.', detail: 'Large-scale computer systems enabled new forms of data processing.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6c/ENIAC_Penn1.jpg/440px-ENIAC_Penn1.jpg', relatedTags: ['Cognitivism', 'Transfer of Learning'], academicArticle: { label: 'Suppes, P. (1966). The Uses of Computers in Education.', url: 'https://doi.org/10.1038/scientificamerican0966-206' } },
  { id: 'laptop-computers', year: 1985, label: 'Laptop Computers', category: 'gentech', brief: 'Portable computers make computing mobile.', detail: 'Laptops enabled 1-to-1 computing initiatives in schools.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/68/Laptop_collage.jpg/440px-Laptop_collage.jpg', relatedTags: ['Transfer of Learning', 'Shortened Distributed Attention'], academicArticle: { label: 'Penuel, W.R. (2006). Implementation of 1-to-1 Computing.', url: 'https://doi.org/10.1080/15391523.2006.10782474' } },
  { id: 'internet-www', year: 1991, label: 'The Internet / WWW', category: 'gentech', brief: 'Berners-Lee releases the first web browser.', detail: 'The WWW democratized access to information.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/LS3_4919_%28cropped%29.jpg/440px-LS3_4919_%28cropped%29.jpg', relatedTags: ['Knowledge Distribution & Classification', 'Shortened Distributed Attention'], academicArticle: { label: 'Berners-Lee, T. et al. (1994). The World-Wide Web.', url: 'https://doi.org/10.1145/179606.179671' } },
  { id: 'wifi', year: 1997, label: 'WiFi', category: 'gentech', brief: 'IEEE 802.11 enables wireless networking.', detail: 'WiFi untethered computing from physical connections.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ae/WiFi_Logo.svg/440px-WiFi_Logo.svg.png', relatedTags: ['Shortened Distributed Attention', 'COVID-19 Pandemic'], academicArticle: { label: 'Warschauer, M. (2006). Laptops and Literacy.', url: 'https://doi.org/10.1177/0895904807307069' } },
  { id: 'smartphones', year: 2007, label: 'Smartphones', category: 'gentech', brief: 'iPhone launches ubiquitous mobile computing.', detail: 'Smartphones put a powerful computer in every pocket.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/IPhone_1st_Gen.svg/440px-IPhone_1st_Gen.svg.png', relatedTags: ['Shortened Distributed Attention', 'COVID-19 Pandemic'], academicArticle: { label: 'Kukulska-Hulme, A. (2009). Will Mobile Learning Change Language Learning?', url: 'https://doi.org/10.1017/S0958344009000202' } },
  { id: 'crispr', year: 2012, label: 'CRISPR Gene Editing', category: 'gentech', brief: 'Doudna and Charpentier develop CRISPR-Cas9.', detail: 'CRISPR gave scientists the ability to precisely edit DNA.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/4QYZ.png/440px-4QYZ.png', relatedTags: ['Transfer of Learning', 'Knowledge Distribution & Classification'], academicArticle: { label: 'Jinek, M. et al. (2012). A Programmable DNA Endonuclease.', url: 'https://doi.org/10.1126/science.1225829' } },
  { id: 'mrna-vaccines', year: 2020, label: 'mRNA Vaccines', category: 'gentech', brief: 'mRNA technology enables rapid COVID-19 vaccine development.', detail: 'mRNA vaccines showed basic science research could rapidly become life-saving technology.', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0d/Ijms-21-06582-g002.webp/440px-Ijms-21-06582-g002.webp.png', relatedTags: ['COVID-19 Pandemic', 'Transfer of Learning'], academicArticle: { label: 'Pardi, N. et al. (2018). mRNA Vaccines.', url: 'https://doi.org/10.1038/nrd.2017.243' } },

  // PSYCHOLOGICAL / LEARNING THEORIES
  { id: 'socrates', year: 1800, label: 'Socrates / Didactic Method', category: 'theory', brief: 'The Socratic method establishes dialogue-based inquiry.', detail: 'Socrates pioneered structured questioning to stimulate critical thinking.', scholar: 'Socrates', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/bc/Socrate_du_Louvre.jpg/440px-Socrate_du_Louvre.jpg', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Plato. Meno, Phaedrus, Republic.', url: 'https://plato.stanford.edu/entries/socrates/' } },
  { id: 'structuralism', year: 1879, label: 'Structuralism', category: 'theory', brief: 'Wundt establishes the first psychology lab.', detail: 'Wundt founded structuralism in Leipzig in 1879.', scholar: 'Wilhelm Wundt', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/Wilhelm_Wundt.jpg/440px-Wilhelm_Wundt.jpg', relatedTags: ['Knowledge Distribution & Classification'], academicArticle: { label: 'Wundt, W. (1874). Principles of Physiological Psychology.', url: 'https://doi.org/10.1037/10868-000' } },
  { id: 'psychoanalysis', year: 1900, label: 'Psychoanalysis', category: 'theory', brief: 'Freud introduces psychoanalysis.', detail: "Freud's psychoanalytic theory proposed unconscious desires shape behavior.", scholar: 'Sigmund Freud', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/Sigmund_Freud%2C_by_Max_Halberstadt_%28cropped%29.jpg/440px-Sigmund_Freud%2C_by_Max_Halberstadt_%28cropped%29.jpg', relatedTags: ['Cognitive Overload'], academicArticle: { label: 'Freud, S. (1900). The Interpretation of Dreams.', url: 'https://doi.org/10.1037/10561-000' } },
  { id: 'gestalt-psychology', year: 1912, label: 'Gestalt Psychology', category: 'theory', brief: 'The mind perceives organized wholes, not isolated parts.', detail: 'Gestalt psychology: the whole is other than the sum of its parts.', scholar: 'Max Wertheimer', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/b9/Max_Werheimer_%281880-1943%29.jpg', relatedTags: ['Cognitive Overload', 'Transfer of Learning'], academicArticle: { label: 'Wertheimer, M. (1912). Experimentelle Studien über das Sehen von Bewegung.', url: 'https://doi.org/10.1007/BF03395367' } },
  { id: 'behaviorism', year: 1913, label: 'Behaviorism', category: 'theory', brief: 'Watson founds behaviorism.', detail: "Watson's behaviorism focused on observable behavior.", scholar: 'John B. Watson', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/ba/John_Broadus_Watson.JPG', relatedTags: ['Transfer of Learning'], academicArticle: { label: 'Watson, J.B. (1913). Psychology as the Behaviorist Views It.', url: 'https://doi.org/10.1037/h0074428' } },
  { id: 'cognitivism', year: 1937, label: 'Cognitivism', category: 'theory', brief: 'Focus shifts to internal mental processes.', detail: 'Cognitivism emphasizes how learners encode, store, and retrieve knowledge.', scholar: 'Jean Piaget', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/6/60/Jean_Piaget_in_Ann_Arbor_%28cropped%29.jpg', relatedTags: ['Cognitive Overload', 'Transfer of Learning'], academicArticle: { label: 'Piaget, J. (1936). Origins of Intelligence in the Child.', url: 'https://doi.org/10.1037/11494-000' } },
  { id: 'hebbian-learning', year: 1949, label: 'Hebbian Learning', category: 'theory', brief: 'Neurons that fire together wire together.', detail: "Hebb's theory became foundational for neuroscience and machine learning.", scholar: 'Donald Hebb', imageUrl: 'https://upload.wikimedia.org/wikipedia/en/1/1d/Donald_Hebb.gif', relatedTags: ['Connectionism'], academicArticle: { label: 'Hebb, D.O. (1949). The Organization of Behavior.', url: 'https://doi.org/10.1002/sce.37303405110' } },
  { id: 'information-processing', year: 1956, label: 'Information Processing Theory', category: 'theory', brief: 'Short-term memory holds 7±2 chunks.', detail: "Miller's landmark paper established the information processing model.", scholar: 'George A. Miller', imageUrl: 'https://upload.wikimedia.org/wikipedia/en/7/7e/George_Armitage_Miller_speaking_at_the_first_Cognitive_Science_conference%2C_UC_San_Diego%2C_1979.jpg', relatedTags: ['Cognitive Overload', 'Cognitivism'], academicArticle: { label: 'Miller, G.A. (1956). The Magical Number Seven.', url: 'https://doi.org/10.1037/h0043158' } },
  { id: 'constructivism', year: 1967, label: 'Constructivism', category: 'theory', brief: 'Learners actively construct knowledge through experience.', detail: 'Piaget argued knowledge is actively built by the learner.', scholar: 'Jean Piaget & Lev Vygotsky', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/6/60/Jean_Piaget_in_Ann_Arbor_%28cropped%29.jpg', relatedTags: ['Transfer of Learning'], academicArticle: { label: 'Piaget, J. (1967). Biology and Knowledge.', url: 'https://doi.org/10.1037/11494-000' } },
  { id: 'critical-pedagogy', year: 1968, label: 'Critical Pedagogy', category: 'theory', brief: 'Freire argues education must be a practice of freedom.', detail: "Freire's Pedagogy of the Oppressed challenged the banking model of education.", scholar: 'Paulo Freire', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Paulo_Freire_1977.jpg/440px-Paulo_Freire_1977.jpg', relatedTags: ['Knowledge Distribution & Classification', 'Transfer of Learning'], academicArticle: { label: 'Freire, P. (1970). Pedagogy of the Oppressed.', url: 'https://doi.org/10.1007/978-3-030-42817-3' } },
  { id: 'social-learning', year: 1977, label: 'Social Learning Theory', category: 'theory', brief: 'Bandura shows learning occurs through observation.', detail: "Bandura's Social Learning Theory: people learn by observing others.", scholar: 'Albert Bandura', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cc/Albert_Bandura_Psychologist.png/440px-Albert_Bandura_Psychologist.png', relatedTags: ['Behaviorism', 'Constructivism'], academicArticle: { label: 'Bandura, A. (1977). Social Learning Theory.', url: 'https://doi.org/10.1177/105960117700200317' } },
  { id: 'connectionism', year: 1986, label: 'Connectionism', category: 'theory', brief: 'Connectionism models cognition through neural networks.', detail: 'Connectionism bridges cognitive science and neural networks.', scholar: 'David Rumelhart & James McClelland', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Artificial_neural_network.svg/440px-Artificial_neural_network.svg.png', relatedTags: ['Cognitivism'], academicArticle: { label: 'Rumelhart, D.E. & McClelland, J.L. (1986). Parallel Distributed Processing.', url: 'https://doi.org/10.7551/mitpress/5236.001.0001' } },
  { id: 'cognitive-load-theory', year: 1988, label: 'Cognitive Load Theory', category: 'theory', brief: 'Sweller formalizes cognitive load in instruction.', detail: "Sweller's CLT distinguishes intrinsic, extraneous, and germane load.", scholar: 'John Sweller', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/RobertFuddBewusstsein17Jh.png/440px-RobertFuddBewusstsein17Jh.png', relatedTags: ['Cognitive Overload', 'Cognitivism'], academicArticle: { label: 'Sweller, J. (1988). Cognitive Load During Problem Solving.', url: 'https://doi.org/10.1207/s15516709cog1202_4' } },
  { id: 'global-workspace', year: 1988, label: 'Global Workspace Theory', category: 'theory', brief: 'Baars proposes consciousness as a global workspace.', detail: "Baars' GWT models consciousness as a theater.", scholar: 'Bernard Baars', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/RobertFuddBewusstsein17Jh.png/440px-RobertFuddBewusstsein17Jh.png', relatedTags: ['Cognitivism'], academicArticle: { label: 'Baars, B.J. (1988). A Cognitive Theory of Consciousness.', url: 'https://doi.org/10.1017/CBO9781139172714' } },
  { id: 'embodied-cognition', year: 1997, label: 'Embodied Cognition', category: 'theory', brief: 'Clark argues the mind extends beyond the brain.', detail: "Clark's thesis: cognitive processes extend through body and environment.", scholar: 'Andy Clark', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/201803_Human_Male.png/440px-201803_Human_Male.png', relatedTags: ['Constructivism', 'Cognitivism'], academicArticle: { label: 'Clark, A. (1997). Being There.', url: 'https://doi.org/10.7551/mitpress/1552.001.0001' } },
  { id: 'free-energy-principle', year: 2006, label: 'Free Energy Principle', category: 'theory', brief: 'Friston: biological systems minimize surprise through prediction.', detail: "Friston's Free Energy Principle unifies brain function understanding.", scholar: 'Karl Friston', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/1206_FMRI.jpg/440px-1206_FMRI.jpg', relatedTags: ['Cognitivism', 'Connectionism'], academicArticle: { label: 'Friston, K. (2006). A Free Energy Principle for the Brain.', url: 'https://doi.org/10.1016/j.jphysparis.2006.10.001' } },
  { id: 'dual-process', year: 2011, label: 'Dual Process Theory', category: 'theory', brief: 'Kahneman distinguishes fast and slow thinking.', detail: "Kahneman's System 1 (fast) and System 2 (slow) thinking.", scholar: 'Daniel Kahneman', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4d/Daniel_Kahneman_%283283955327%29.jpg/440px-Daniel_Kahneman_%283283955327%29.jpg', relatedTags: ['Cognitive Overload', 'Cognitivism'], academicArticle: { label: 'Kahneman, D. (2011). Thinking, Fast and Slow.', url: 'https://doi.org/10.1007/s00362-013-0533-y' } },

  // INSTRUCTIONAL CHALLENGES
  { id: 'knowledge-distribution', year: 1820, label: 'Knowledge Distribution & Classification', category: 'challenge', brief: 'Early education struggles with organizing and distributing knowledge.', detail: 'The challenge of classifying and distributing knowledge limited who could learn.' },
  { id: 'natural-disasters', year: 1870, label: 'Natural Disasters / Disruptions', category: 'challenge', brief: 'Wars, plagues, and natural disasters disrupt educational continuity.', detail: 'Natural disasters, wars, and pandemics have disrupted education systems.' },
  { id: 'lack-standardized-assessment', year: 1880, label: 'Lack of Standardized Assessment', category: 'challenge', brief: 'Without standardized assessment, measuring outcomes remains inconsistent.', detail: 'Before standardized testing, there was no reliable way to measure student learning.' },
  { id: 'cognitive-overload', year: 1940, label: 'Cognitive Overload', category: 'challenge', brief: 'Information exceeds cognitive processing capacity.', detail: 'As content expanded with new media, cognitive overload became a recognized barrier.' },
  { id: 'transfer-of-learning', year: 2005, label: 'Transfer of Learning', category: 'challenge', brief: 'Students struggle to apply knowledge to new situations.', detail: "Transfer remains one of education's most persistent problems." },
  { id: 'shortened-attention', year: 2015, label: 'Shortened Distributed Attention', category: 'challenge', brief: 'Digital environments fragment attention.', detail: 'Smartphones, social media, and notifications created distributed attention.' },
  { id: 'covid-pandemic', year: 2020, label: 'COVID-19 Pandemic', category: 'challenge', brief: 'COVID-19 forces emergency remote teaching.', detail: 'The pandemic shift revealed millions lacked reliable internet and devices.' },
];

const categoryToSheet: Record<string, string> = {
  theory: 'Psychological/Learning Theory',
  edtech: 'Educational Technology',
  gentech: 'General Technology',
  challenge: 'Instructional Challenges',
};

function itemToRow(item: TimelineItem): { sheetName: string; row: string[] } {
  const cat = item.category;
  const sheetName = categoryToSheet[cat] || 'Educational Technology';

  if (cat === 'theory') {
    return { sheetName, row: [
      item.id, String(item.year), item.label, item.scholar || '',
      item.brief, item.detail, item.imageUrl || '',
      (item.relatedTags || []).join(', '),
      item.academicArticle?.label || '', item.academicArticle?.url || '',
    ]};
  } else if (cat === 'challenge') {
    return { sheetName, row: [
      item.id, String(item.year), item.label, item.brief, item.detail,
    ]};
  } else {
    return { sheetName, row: [
      item.id, String(item.year), item.label, item.brief, item.detail,
      item.imageUrl || '', (item.relatedTags || []).join(', '),
      item.academicArticle?.label || '', item.academicArticle?.url || '',
    ]};
  }
}

// ---------------- Validation helpers ----------------
const VALID_CATEGORIES = new Set(['edtech', 'gentech', 'theory', 'challenge']);
const MAX_TAGS = 20;
const MAX_TAG_LEN = 80;

function isSafeUrl(u: unknown): u is string {
  if (typeof u !== 'string' || u.length === 0 || u.length > 2000) return false;
  try {
    const parsed = new URL(u);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

function validateItem(raw: any): { ok: true; item: TimelineItem } | { ok: false; error: string } {
  if (!raw || typeof raw !== 'object') return { ok: false, error: 'Invalid item' };

  const id = typeof raw.id === 'string' && raw.id.length > 0 && raw.id.length <= 100 ? raw.id : null;
  if (!id) return { ok: false, error: 'Invalid id' };

  const year = typeof raw.year === 'number' && Number.isFinite(raw.year) && raw.year >= -3000 && raw.year <= 2100
    ? Math.floor(raw.year) : null;
  if (year === null) return { ok: false, error: 'Invalid year' };

  if (typeof raw.category !== 'string' || !VALID_CATEGORIES.has(raw.category)) {
    return { ok: false, error: 'Invalid category' };
  }

  if (typeof raw.label !== 'string' || raw.label.trim().length === 0 || raw.label.length > 200) {
    return { ok: false, error: 'Invalid label' };
  }
  if (typeof raw.brief !== 'string' || raw.brief.length > 500) {
    return { ok: false, error: 'Invalid brief' };
  }
  if (typeof raw.detail !== 'string' || raw.detail.length > 2000) {
    return { ok: false, error: 'Invalid detail' };
  }

  if (raw.imageUrl !== undefined && raw.imageUrl !== '' && !isSafeUrl(raw.imageUrl)) {
    return { ok: false, error: 'Invalid imageUrl' };
  }
  if (raw.scholar !== undefined && (typeof raw.scholar !== 'string' || raw.scholar.length > 200)) {
    return { ok: false, error: 'Invalid scholar' };
  }

  let relatedTags: string[] | undefined;
  if (raw.relatedTags !== undefined) {
    if (!Array.isArray(raw.relatedTags) || raw.relatedTags.length > MAX_TAGS) {
      return { ok: false, error: 'Invalid relatedTags' };
    }
    relatedTags = [];
    for (const t of raw.relatedTags) {
      if (typeof t !== 'string' || t.length === 0 || t.length > MAX_TAG_LEN) {
        return { ok: false, error: 'Invalid tag' };
      }
      relatedTags.push(t);
    }
  }

  let sources: { label: string; url: string }[] | undefined;
  if (raw.sources !== undefined) {
    if (!Array.isArray(raw.sources) || raw.sources.length > 10) {
      return { ok: false, error: 'Invalid sources' };
    }
    sources = [];
    for (const s of raw.sources) {
      if (!s || typeof s.label !== 'string' || s.label.length === 0 || s.label.length > 200 || !isSafeUrl(s.url)) {
        return { ok: false, error: 'Invalid source entry' };
      }
      sources.push({ label: s.label, url: s.url });
    }
  }

  let academicArticle: { label: string; url: string } | undefined;
  if (raw.academicArticle !== undefined) {
    const a = raw.academicArticle;
    if (!a || typeof a.label !== 'string' || a.label.length === 0 || a.label.length > 300 || !isSafeUrl(a.url)) {
      return { ok: false, error: 'Invalid academicArticle' };
    }
    academicArticle = { label: a.label, url: a.url };
  }

  return {
    ok: true,
    item: {
      id, year, label: raw.label, category: raw.category,
      brief: raw.brief, detail: raw.detail,
      imageUrl: raw.imageUrl || undefined,
      relatedTags, sources, academicArticle,
      scholar: raw.scholar || undefined,
    },
  };
}

// Simple in-memory rate limiter (per IP, best-effort)
const rateBuckets = new Map<string, { count: number; reset: number }>();
function checkRate(ip: string, limit = 10, windowMs = 60_000): boolean {
  const now = Date.now();
  const b = rateBuckets.get(ip);
  if (!b || b.reset < now) {
    rateBuckets.set(ip, { count: 1, reset: now + windowMs });
    return true;
  }
  if (b.count >= limit) return false;
  b.count++;
  return true;
}

function errorResponse(status: number, message: string): Response {
  return new Response(JSON.stringify({ error: message }), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const serviceAccountJson = Deno.env.get('GOOGLE_SERVICE_ACCOUNT_JSON');
    const spreadsheetId = Deno.env.get('GOOGLE_SHEETS_SPREADSHEET_ID');
    if (!serviceAccountJson || !spreadsheetId) {
      console.error('Missing required configuration for sync-google-sheets');
      return errorResponse(500, 'Service temporarily unavailable.');
    }

    // Parse body first so we can branch on action before doing expensive work
    let body: any = null;
    if (req.method === 'POST') {
      try {
        body = await req.json();
      } catch {
        body = null;
      }
    }

    // Append (public submission) path: validate strictly + rate limit
    if (body?.action === 'append') {
      const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
      if (!checkRate(ip)) {
        return errorResponse(429, 'Too many requests. Please try again later.');
      }

      const validation = validateItem(body.item);
      if (!validation.ok) {
        return errorResponse(400, `Validation failed: ${validation.error}`);
      }

      const accessToken = await getAccessToken(serviceAccountJson);
      const { sheetName, row } = itemToRow(validation.item);
      await appendRowToSheet(accessToken, spreadsheetId, sheetName, row);
      console.log(`Appended item to ${sheetName}`);
      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Full sync path: restrict to authenticated callers (admin/maintenance op)
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return errorResponse(401, 'Unauthorized');
    }
    try {
      const { createClient } = await import('https://esm.sh/@supabase/supabase-js@2');
      const supabaseUrl = Deno.env.get('SUPABASE_URL');
      const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY');
      if (!supabaseUrl || !supabaseAnonKey) {
        return errorResponse(500, 'Service temporarily unavailable.');
      }
      const supabase = createClient(supabaseUrl, supabaseAnonKey);
      const token = authHeader.replace('Bearer ', '');
      const { data, error } = await supabase.auth.getUser(token);
      if (error || !data?.user) {
        return errorResponse(401, 'Unauthorized');
      }
    } catch (e) {
      console.error('Auth check failed:', e);
      return errorResponse(401, 'Unauthorized');
    }

    const accessToken = await getAccessToken(serviceAccountJson);

    // Full sync mode (default)
    const techHeaders = ['ID', 'Year', 'Name', 'Brief Description', 'Detailed Description', 'Image URL', 'Related Tags', 'Academic Article Label', 'Academic Article URL'];
    const theoryHeaders = ['ID', 'Year', 'Name', 'Scholar', 'Brief Description', 'Detailed Description', 'Image URL', 'Related Tags', 'Academic Article Label', 'Academic Article URL'];
    const challengeHeaders = ['ID', 'Year', 'Name', 'Brief Description', 'Detailed Description'];

    const results: Record<string, number> = {};

    for (const [cat, sheetName] of Object.entries(categoryToSheet)) {
      const items = timelineItems.filter(i => i.category === cat);
      let rows: string[][];

      if (cat === 'theory') {
        rows = [theoryHeaders, ...items.map(i => [
          i.id, String(i.year), i.label, i.scholar || '',
          i.brief, i.detail, i.imageUrl || '',
          (i.relatedTags || []).join(', '),
          i.academicArticle?.label || '', i.academicArticle?.url || '',
        ])];
      } else if (cat === 'challenge') {
        rows = [challengeHeaders, ...items.map(i => [
          i.id, String(i.year), i.label, i.brief, i.detail,
        ])];
      } else {
        rows = [techHeaders, ...items.map(i => [
          i.id, String(i.year), i.label, i.brief, i.detail,
          i.imageUrl || '', (i.relatedTags || []).join(', '),
          i.academicArticle?.label || '', i.academicArticle?.url || '',
        ])];
      }

      await clearAndWriteSheet(accessToken, spreadsheetId, sheetName, rows);
      results[sheetName] = items.length;
    }

    return new Response(JSON.stringify({ success: true, itemsWritten: results }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    const msg = error instanceof Error ? error.message : 'Unknown error';
    console.error('Sync error:', msg);
    return errorResponse(500, 'Sync failed. Please try again.');
  }
});
