import { useState, useCallback, useRef, useEffect } from "react";
import InteractiveTimeline from "@/components/InteractiveTimeline";
import TimelineListView from "@/components/TimelineListView";
import TimelineItemForm from "@/components/TimelineItemForm";
import { timelineItems as initialItems, TimelineItem, CategoryType } from "@/data/timelineData";
import { supabase } from "@/integrations/supabase/client";

import { ChevronDown } from "lucide-react";

const Index = () => {
  const [userItems, setUserItems] = useState<TimelineItem[]>([]);
  const [playIntro, setPlayIntro] = useState(false);
  const timelineSectionRef = useRef<HTMLDivElement>(null);
  const hasPlayedRef = useRef(false);

  useEffect(() => {
    const node = timelineSectionRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !hasPlayedRef.current) {
            hasPlayedRef.current = true;
            setPlayIntro(true);
          }
        });
      },
      { threshold: 0.2 },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  const handleAddItem = useCallback(
    async (data: {
      label: string;
      year: number;
      category: CategoryType;
      brief: string;
      detail: string;
      sourceLabel?: string;
      sourceUrl?: string;
      imageUrl?: string;
      relatedTags?: string[];
      academicArticleLabel?: string;
      academicArticleUrl?: string;
    }) => {
      const newItem: TimelineItem = {
        id: `user-${Date.now()}`,
        year: data.year,
        label: data.label,
        category: data.category,
        brief: data.brief,
        detail: data.detail,
        sources: data.sourceLabel && data.sourceUrl ? [{ label: data.sourceLabel, url: data.sourceUrl }] : undefined,
        imageUrl: data.imageUrl,
        relatedTags: data.relatedTags,
        academicArticle:
          data.academicArticleLabel && data.academicArticleUrl
            ? { label: data.academicArticleLabel, url: data.academicArticleUrl }
            : undefined,
      };
      setUserItems((prev) => [...prev, newItem]);

      // Sync to Google Sheets
      try {
        const { data: result, error } = await supabase.functions.invoke("sync-google-sheets", {
          body: { action: "append", item: newItem },
        });
        if (error) {
          console.error("Sheets sync error:", error);
        } else {
          console.log("Synced to Google Sheets:", result);
        }
      } catch (err) {
        console.error("Failed to sync to Google Sheets:", err);
      }
    },
    [],
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Hero — Soft cream background for AAA contrast */}
      <header className="relative overflow-hidden bg-[#FBF7F1] text-[#1F2937] min-h-screen flex flex-col">
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: "radial-gradient(circle at 1px 1px, #011F5B 1px, transparent 0)",
            backgroundSize: "32px 32px",
          }}
        />

        <div className="relative mx-auto flex max-w-6xl flex-1 flex-col items-center justify-center px-6 py-16 text-center">
          {/* Eyebrow */}
          <div className="mb-5 flex items-center justify-center gap-3">
            <span className="inline-block h-[2px] w-10 bg-[#990000]" />
            <span className="font-body text-xs font-semibold uppercase tracking-[0.25em] text-[#990000]">
              University of Pennsylvania • Penn AI • Graduate School of Education
            </span>
            <span className="inline-block h-[2px] w-10 bg-[#990000]" />
          </div>

          {/* Title */}
          <h1 className="font-display text-4xl font-bold text-[#011F5B] md:text-5xl lg:text-6xl leading-tight">
            AI Pedagogy Wiki
          </h1>


          {/* Wiki intro */}
          <div className="mx-auto mt-6 max-w-2xl font-body text-base text-[#1F2937] leading-relaxed space-y-3">
            <p>
              This is a living wiki on AI and pedagogy — a collaborative reference for the ideas, tools, and research
              shaping AI-enhanced teaching and learning. It is not the PAPI home page; it is a curated knowledge base
              maintained alongside the initiative, where educators can trace how learning technologies evolved, compare
              pedagogical affordances, and contribute entries of their own.
            </p>
          </div>


          <div className="mt-8 flex flex-wrap items-center justify-center gap-4 font-body text-sm">
            <a
              href="https://www.gse.upenn.edu/our-expertise/penn-ai-pedagogy-initiative"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-full border-2 border-[#011F5B] bg-transparent px-4 py-1.5 font-semibold text-[#011F5B] hover:bg-[#011F5B] hover:text-[#FBF7F1] transition-colors"
            >
              About PAPI
            </a>
            <a
              href="https://studio.pennai-pedagogy.org/"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-full border-2 border-[#011F5B] bg-transparent px-4 py-1.5 font-semibold text-[#011F5B] hover:bg-[#011F5B] hover:text-[#FBF7F1] transition-colors"
            >
              PAPI Studio
            </a>
            <a
              href="https://www.gse.upenn.edu/our-expertise/artificial-intelligence-education-lab"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-full border-2 border-[#011F5B] bg-transparent px-4 py-1.5 font-semibold text-[#011F5B] hover:bg-[#011F5B] hover:text-[#FBF7F1] transition-colors"
            >
              About AIED Lab
            </a>
          </div>
        </div>

        {/* Scroll cue */}
        <div className="relative pb-8 flex justify-center animate-bounce">
          <ChevronDown className="text-[#011F5B]/70" size={28} />
        </div>
      </header>

      {/* Timeline */}
      <main className="mx-auto max-w-7xl px-4 py-12">
        <div ref={timelineSectionRef} className="mb-8 text-center">
          <h2 className="font-display text-2xl font-bold text-foreground md:text-3xl">
            Tech Tools in Teaching &amp; Learning — An Interactive Timeline
          </h2>
          <p className="mt-2 font-body text-sm text-muted-foreground">
            Explore the evolving convergence of technology, learning sciences, and artificial intelligence
          </p>
        </div>

        <InteractiveTimeline extraItems={userItems} playIntro={playIntro} />

        {/* Project Description */}
        <div className="mt-12 rounded-xl border border-border bg-card p-8 shadow-sm">
          <h3 className="font-display text-xl font-bold text-foreground mb-3">About This Timeline</h3>
          <p className="font-body text-sm text-muted-foreground leading-relaxed">
            PAPI develops this interactive timeline as an ongoing inquiry into the pedagogical affordances and
            limitations of technology in teaching and learning. We are building a working categorization to help faculty
            match tools to appropriate learning contexts, and to distinguish challenges that AI has introduced from
            those that educators have always faced. As our world accelerates, this timeline helps us conceptualize and
            organize our collective response.
          </p>
          <div className="mt-4">
            <div className="rounded-lg border border-border bg-muted/50 p-4">
              <p className="font-body text-xs font-semibold text-foreground mb-2">Data Sources</p>
              <ul className="space-y-2 font-body text-xs text-muted-foreground leading-relaxed list-none">
                <li>
                  Riedl, A. (2019). <em>Historical map of (the) cognitive science(s): An attempt</em> [Visual map].{" "}
                  <a
                    href="https://www.riedlanna.com/cognitivesciencemap.html"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-semibold text-penn-blue hover:underline"
                  >
                    https://www.riedlanna.com/cognitivesciencemap.html
                  </a>
                </li>
                <li>
                  Roser, M. (2023). A long-term timeline of technology. <em>Our World in Data</em>. Licensed under
                  CC-BY.{" "}
                  <a
                    href="https://ourworldindata.org/technology-long-run"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-semibold text-penn-blue hover:underline"
                  >
                    https://ourworldindata.org/technology-long-run
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* List View */}
        <div className="mt-12">
          <h3 className="font-display text-xl font-bold text-foreground mb-4">Timeline Items — List View</h3>
          <TimelineListView />
        </div>

        {/* Add Item Form */}
        <div className="mt-12">
          <h3 className="font-display text-xl font-bold text-foreground mb-4">Suggest a Timeline Item</h3>
          <p className="font-body text-sm text-muted-foreground mb-4">
            Help us build this timeline. Submit an event, theory, or milestone to be considered for inclusion.
          </p>
          <TimelineItemForm onSubmit={handleAddItem} />
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-primary py-10 text-center">
        <p className="font-body text-xs text-primary-foreground/60">
          © {new Date().getFullYear()} PennAI Apprenticeship Pedagogy Initiative — University of Pennsylvania, Graduate
          School of Education
        </p>
      </footer>
    </div>
  );
};

export default Index;
