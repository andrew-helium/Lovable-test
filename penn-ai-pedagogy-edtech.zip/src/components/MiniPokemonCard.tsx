import { TimelineItem } from '@/data/timelineData';
import { BookOpen, Zap, Cpu, AlertTriangle } from 'lucide-react';
import CardImageFrame from './CardImageFrame';

interface MiniPokemonCardProps {
  item: TimelineItem;
}

const config = {
  theory: { border: 'border-theory', banner: 'bg-gradient-to-r from-theory/90 to-theory/70', plate: 'bg-gradient-to-r from-theory/20 to-theory/10', bar: 'bg-gradient-to-r from-theory/60 via-theory to-theory/60', img: 'border-theory/40', label: 'Learning Theory', icon: BookOpen, bg: 'linear-gradient(135deg, hsl(145 40% 92%), hsl(150 45% 96%), hsl(145 40% 92%))' },
  edtech: { border: 'border-tech', banner: 'bg-gradient-to-r from-tech/90 to-tech/70', plate: 'bg-gradient-to-r from-tech/20 to-tech/10', bar: 'bg-gradient-to-r from-tech/60 via-tech to-tech/60', img: 'border-tech/40', label: 'Educational Technology', icon: Zap, bg: 'linear-gradient(135deg, hsl(40 80% 94%), hsl(45 90% 97%), hsl(40 80% 94%))' },
  gentech: { border: 'border-gentech', banner: 'bg-gradient-to-r from-gentech/90 to-gentech/70', plate: 'bg-gradient-to-r from-gentech/20 to-gentech/10', bar: 'bg-gradient-to-r from-gentech/60 via-gentech to-gentech/60', img: 'border-gentech/40', label: 'General Technology', icon: Cpu, bg: 'linear-gradient(135deg, hsl(210 55% 93%), hsl(215 50% 96%), hsl(210 55% 93%))' },
  challenge: { border: 'border-challenge', banner: 'bg-gradient-to-r from-challenge/90 to-challenge/70', plate: 'bg-gradient-to-r from-challenge/20 to-challenge/10', bar: 'bg-gradient-to-r from-challenge/60 via-challenge to-challenge/60', img: 'border-challenge/40', label: 'Instructional Challenge', icon: AlertTriangle, bg: 'linear-gradient(135deg, hsl(0 40% 94%), hsl(0 45% 97%), hsl(0 40% 94%))' },
};

export default function MiniPokemonCard({ item }: MiniPokemonCardProps) {
  const c = config[item.category];
  const Icon = c.icon;

  return (
    <div
      className={`relative overflow-hidden rounded-2xl border-[3px] ${c.border} shadow-xl w-72`}
      style={{ background: c.bg }}
    >
      <div className={`flex items-center justify-between px-4 py-2 ${c.banner}`}>
        <span className="font-display text-[10px] font-bold text-white uppercase tracking-wider opacity-90">
          {c.label}
        </span>
        <div className="flex items-center gap-1.5">
          <Icon size={12} className="text-white" />
          <span className="font-body text-xs font-bold text-white">{item.year}</span>
        </div>
      </div>

      <CardImageFrame
        imageUrl={item.imageUrl}
        alt={item.scholar || item.label}
        compact
        borderClass={c.img}
        fallback={<Icon size={40} className="text-muted-foreground/30" />}
      />

      {item.scholar && (
        <div className="mx-3 mt-1 px-1">
          <p className="font-body text-[9px] font-semibold text-theory uppercase tracking-wider">
            {item.scholar}
          </p>
        </div>
      )}

      <div className={`mx-3 mt-1 rounded-lg ${c.plate} px-3 py-1.5`}>
        <h3 className="font-display font-bold text-foreground text-sm">{item.label}</h3>
      </div>

      <div className="mx-3 mt-2 mb-3 px-1">
        <p className="font-body text-xs text-foreground/80 leading-relaxed line-clamp-3">
          {item.brief}
        </p>
      </div>

      <div className={`h-1.5 ${c.bar}`} />
    </div>
  );
}
