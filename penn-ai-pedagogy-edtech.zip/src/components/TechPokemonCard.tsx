import { TimelineItem } from '@/data/timelineData';
import { X, ExternalLink, Zap, Cpu } from 'lucide-react';
import CardImageFrame from './CardImageFrame';

interface TechPokemonCardProps {
  item: TimelineItem;
  onClose?: () => void;
  compact?: boolean;
}

export default function TechPokemonCard({ item, onClose, compact = false }: TechPokemonCardProps) {
  const isGenTech = item.category === 'gentech';
  const borderColor = isGenTech ? 'border-gentech' : 'border-tech';
  const gradientBg = isGenTech
    ? 'linear-gradient(135deg, hsl(210 55% 93%), hsl(215 50% 96%), hsl(210 55% 93%))'
    : 'linear-gradient(135deg, hsl(40 80% 94%), hsl(45 90% 97%), hsl(40 80% 94%))';
  const bannerClass = isGenTech
    ? 'bg-gradient-to-r from-gentech/90 to-gentech/70'
    : 'bg-gradient-to-r from-tech/90 to-tech/70';
  const namePlateBg = isGenTech
    ? 'bg-gradient-to-r from-gentech/20 to-gentech/10'
    : 'bg-gradient-to-r from-tech/20 to-tech/10';
  const bottomBar = isGenTech
    ? 'bg-gradient-to-r from-gentech/60 via-gentech to-gentech/60'
    : 'bg-gradient-to-r from-tech/60 via-tech to-tech/60';
  const imgBorder = isGenTech ? 'border-gentech/40' : 'border-tech/40';
  const typeLabel = isGenTech ? 'General Technology' : 'Educational Technology';
  const TypeIcon = isGenTech ? Cpu : Zap;

  return (
    <div
      className={`relative overflow-hidden rounded-2xl border-[3px] ${borderColor} shadow-xl ${
        compact ? 'max-w-sm' : 'w-full max-w-md'
      }`}
      style={{ background: gradientBg }}
    >
      <div className={`flex items-center justify-between px-4 py-2 ${bannerClass}`}>
        <span className="font-display text-xs font-bold text-white uppercase tracking-wider opacity-90">
          {typeLabel}
        </span>
        <div className="flex items-center gap-1.5">
          <TypeIcon size={12} className="text-white" />
          <span className="font-body text-xs font-bold text-white">{item.year}</span>
        </div>
        {!compact && onClose && (
          <button onClick={onClose} className="rounded-full p-0.5 hover:bg-white/20 transition-colors">
            <X size={16} className="text-white" />
          </button>
        )}
      </div>

      <CardImageFrame
        imageUrl={item.imageUrl}
        alt={item.label}
        compact={compact}
        borderClass={imgBorder}
        fallback={<TypeIcon size={48} className="text-muted-foreground/30" />}
      />

      <div className={`mx-3 mt-2 rounded-lg ${namePlateBg} px-3 py-1.5`}>
        <h3 className={`font-display font-bold text-foreground ${compact ? 'text-base' : 'text-lg'}`}>
          {item.label}
        </h3>
      </div>

      <div className="mx-3 mt-2 px-1">
        <p className={`font-body text-foreground/80 leading-relaxed ${compact ? 'text-xs' : 'text-sm'}`}>
          {compact ? item.brief : item.detail}
        </p>
      </div>

      {item.relatedTags && item.relatedTags.length > 0 && (
        <div className="mx-3 mt-3 rounded-lg border border-border bg-card/60 p-2.5">
          <p className="font-body text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5">Related</p>
          <div className="flex flex-wrap gap-1.5">
            {item.relatedTags.map((tag) => {
              const isChallenge = [
                'Knowledge Distribution & Classification', 'Natural Disasters / Disruptions',
                'Lack of Standardized Assessment', 'Cognitive Overload', 'Transfer of Learning',
                'Shortened Distributed Attention', 'COVID-19 Pandemic',
              ].includes(tag);
              return (
                <span
                  key={tag}
                  className={`inline-flex items-center rounded-full px-2 py-0.5 font-body text-[10px] font-semibold border ${
                    isChallenge
                      ? 'border-challenge/30 bg-challenge-light text-challenge'
                      : 'border-theory/30 bg-theory-light text-theory'
                  }`}
                >
                  {tag}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {item.academicArticle && (
        <div className="mx-3 mt-2 mb-3 rounded-lg border border-border bg-card/60 p-2.5">
          <p className="font-body text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">Key Research</p>
          <a
            href={item.academicArticle.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-start gap-1.5 font-body text-xs text-penn-blue-light hover:underline leading-snug"
          >
            <ExternalLink size={10} className="mt-0.5 flex-shrink-0" />
            {item.academicArticle.label}
          </a>
        </div>
      )}

      <div className={`h-1.5 ${bottomBar}`} />
    </div>
  );
}
