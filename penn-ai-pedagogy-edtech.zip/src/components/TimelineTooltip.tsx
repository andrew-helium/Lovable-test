import { useState, useRef, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { TimelineItem } from '@/data/timelineData';
import { X, ExternalLink } from 'lucide-react';
import TechPokemonCard from './TechPokemonCard';
import TheoryPokemonCard from './TheoryPokemonCard';

interface TimelineTooltipProps {
  item: TimelineItem;
  children: React.ReactNode;
}

const categoryStyles: Record<string, { border: string; bg: string; dot: string }> = {
  theory: { border: 'border-theory', bg: 'bg-theory-light', dot: 'bg-theory' },
  edtech: { border: 'border-tech', bg: 'bg-tech-light', dot: 'bg-tech' },
  gentech: { border: 'border-gentech', bg: 'bg-gentech-light', dot: 'bg-gentech' },
  challenge: { border: 'border-challenge', bg: 'bg-challenge-light', dot: 'bg-challenge' },
};

export default function TimelineTooltip({ item, children }: TimelineTooltipProps) {
  const [showBrief, setShowBrief] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [tooltipPos, setTooltipPos] = useState({ top: 0, left: 0 });
  const triggerRef = useRef<HTMLDivElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const style = categoryStyles[item.category];
  const isTech = item.category === 'edtech' || item.category === 'gentech';
  const isTheory = item.category === 'theory';

  const hideTimeout = useRef<ReturnType<typeof setTimeout>>();

  const updatePosition = useCallback(() => {
    // Always center the tooltip in the viewport
    const tooltipW = 288;
    const tooltipH = 120; // approximate
    const left = Math.max(8, (window.innerWidth - tooltipW) / 2);
    const top = Math.max(8, (window.innerHeight - tooltipH) / 2);
    setTooltipPos({ top, left });
  }, []);

  const handleMouseEnter = () => {
    clearTimeout(hideTimeout.current);
    if (!pinned && !expanded) {
      setShowBrief(true);
      updatePosition();
    }
  };

  const handleMouseLeave = () => {
    if (!pinned) {
      // Delay hiding so user can move mouse to the tooltip
      hideTimeout.current = setTimeout(() => setShowBrief(false), 250);
    }
  };

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (pinned) {
      // Already pinned — unpin
      setPinned(false);
      setShowBrief(false);
    } else {
      // Pin the tooltip
      setPinned(true);
      setShowBrief(true);
      updatePosition();
    }
  };

  // Close pinned tooltip when clicking outside
  useEffect(() => {
    if (!pinned) return;
    const handleOutsideClick = (e: MouseEvent) => {
      if (
        triggerRef.current && !triggerRef.current.contains(e.target as Node) &&
        tooltipRef.current && !tooltipRef.current.contains(e.target as Node)
      ) {
        setPinned(false);
        setShowBrief(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, [pinned]);

  const briefTooltip = (showBrief || pinned) && !expanded ? createPortal(
    <AnimatePresence>
      <motion.div
        ref={tooltipRef}
        initial={{ opacity: 0, y: 8, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 8, scale: 0.95 }}
        transition={{ duration: 0.15 }}
        className={`fixed z-[200] w-72 rounded-lg border ${style.border} ${style.bg} p-4 shadow-xl`}
        style={{ top: tooltipPos.top, left: tooltipPos.left }}
        onMouseEnter={() => { clearTimeout(hideTimeout.current); }}
        onMouseLeave={() => { if (!pinned) { hideTimeout.current = setTimeout(() => setShowBrief(false), 250); } }}
      >
        <p className="font-body text-sm text-foreground leading-relaxed">{item.brief}</p>
        <button
          onClick={(e) => { e.stopPropagation(); setExpanded(true); setShowBrief(false); setPinned(false); }}
          className="mt-3 inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 font-body text-xs font-semibold text-primary-foreground transition-colors hover:opacity-90"
        >
          Learn More
        </button>
      </motion.div>
    </AnimatePresence>,
    document.body
  ) : null;

  return (
    <>
      <div
        ref={triggerRef}
        className="relative inline-block"
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        onClick={handleClick}
      >
        {children}
      </div>

      {briefTooltip}

      {/* Expanded modal overlay — portaled to body to escape transformed ancestors */}
      {expanded && createPortal(
        <AnimatePresence>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] flex items-center justify-center bg-foreground/40 backdrop-blur-sm p-4"
            onClick={() => { setExpanded(false); setShowBrief(false); setPinned(false); }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className="max-h-[90vh] overflow-y-auto"
            >
              {isTech ? (
                <TechPokemonCard
                  item={item}
                  onClose={() => { setExpanded(false); setShowBrief(false); setPinned(false); }}
                />
              ) : isTheory ? (
                <TheoryPokemonCard
                  item={item}
                  onClose={() => { setExpanded(false); setShowBrief(false); setPinned(false); }}
                />
              ) : (
                <div className={`relative w-full max-w-lg rounded-xl border-2 ${style.border} bg-card p-6 shadow-2xl`}>
                  <button
                    onClick={() => { setExpanded(false); setShowBrief(false); setPinned(false); }}
                    className="absolute right-4 top-4 rounded-full p-1 text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
                  >
                    <X size={18} />
                  </button>

                  <div className="flex items-center gap-3 mb-4">
                    <span className={`inline-block h-3 w-3 rounded-full ${style.dot}`} />
                    <span className="font-body text-sm font-semibold text-muted-foreground">{item.year}</span>
                  </div>

                  <h3 className="font-display text-xl font-bold text-foreground mb-3">{item.label}</h3>
                  <p className="font-body text-sm text-foreground/80 leading-relaxed mb-4">{item.detail}</p>

                  {item.sources && item.sources.length > 0 && (
                    <div className="border-t border-border pt-3">
                      <p className="font-body text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                        Academic Sources
                      </p>
                      <ul className="space-y-1.5">
                        {item.sources.map((s, i) => (
                          <li key={i}>
                            <a
                              href={s.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 font-body text-xs text-penn-blue-light hover:underline"
                            >
                              <ExternalLink size={12} />
                              {s.label}
                            </a>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          </motion.div>
        </AnimatePresence>,
        document.body
      )}
    </>
  );
}
