import { HelpCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface FieldHelpProps {
  text: string;
}

export default function FieldHelp({ text }: FieldHelpProps) {
  return (
    <Tooltip delayDuration={150}>
      <TooltipTrigger asChild>
        <button
          type="button"
          onClick={(e) => e.stopPropagation()}
          className="inline-flex items-center justify-center rounded-full text-muted-foreground hover:text-foreground transition-colors"
          aria-label="Field help"
        >
          <HelpCircle size={13} />
        </button>
      </TooltipTrigger>
      <TooltipContent side="top" sideOffset={6} className="z-[9999] max-w-xs text-xs leading-relaxed">
        {text}
      </TooltipContent>
    </Tooltip>
  );
}
