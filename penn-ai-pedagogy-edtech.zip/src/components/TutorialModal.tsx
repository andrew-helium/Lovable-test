import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronLeft, ChevronRight, MousePointer2, ZoomIn, ZoomOut, Search } from 'lucide-react';

interface TutorialModalProps {
  open: boolean;
  onClose: () => void;
}

/* ── Slide 1: Filters & Controls ── */
function Slide1() {
  const [active, setActive] = useState(true);
  const [showBars, setShowBars] = useState(false);
  const [showPolicies, setShowPolicies] = useState(false);
  const [selectedEra, setSelectedEra] = useState('all');

  const demoEras = [
    { value: 'all', label: 'All Eras' },
    { value: 'pre1950', label: 'Pre-Digital (before 1950)' },
    { value: '1950-1979', label: 'Early Computing (1950–1979)' },
    { value: '1980-1999', label: 'PC & Internet (1980–1999)' },
    { value: '2000-2014', label: 'Web 2.0 (2000–2014)' },
    { value: '2015-present', label: 'AI Era (2015–present)' },
  ];

  return (
    <div className="flex flex-col items-center gap-5 px-4">
      <h3 className="font-display text-lg font-bold text-foreground">Filters & Controls</h3>

      {/* Category filter */}
      <div className="flex flex-col items-center gap-2 w-full max-w-sm">
        <p className="text-xs text-muted-foreground text-center leading-relaxed">
          Click a <strong>category label</strong> to toggle items on and off. Try it!
        </p>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActive((a) => !a)}
            className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all text-xs font-medium ${
              active
                ? 'border-theory/40 bg-theory/10 opacity-100'
                : 'border-border bg-muted opacity-40'
            }`}
          >
            <span className="inline-block h-2.5 w-2.5 rounded-full bg-theory" />
            <span className={active ? 'text-theory' : 'text-muted-foreground'}>
              Theories
            </span>
          </button>
          <AnimatePresence>
            {active ? (
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} className="flex gap-1.5">
                {[0, 1, 2].map((i) => (
                  <motion.div key={i} initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} transition={{ delay: i * 0.05 }} className="h-4 w-4 rounded-full bg-theory shadow-sm" />
                ))}
              </motion.div>
            ) : (
              <span className="text-[10px] text-muted-foreground italic">hidden</span>
            )}
          </AnimatePresence>
        </div>
      </div>

      <div className="w-full max-w-sm h-px bg-border" />

      {/* Era dropdown */}
      <div className="flex flex-col items-center gap-2 w-full max-w-sm">
        <p className="text-xs text-muted-foreground text-center leading-relaxed">
          The <strong>Era dropdown</strong> zooms the timeline to the selected time period.
        </p>
        <select
          value={selectedEra}
          onChange={(e) => setSelectedEra(e.target.value)}
          className="rounded-full border border-border bg-muted px-3 py-1.5 font-body text-xs font-semibold text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring"
        >
          {demoEras.map((era) => (
            <option key={era.value} value={era.value}>{era.label}</option>
          ))}
        </select>
      </div>

      <div className="w-full max-w-sm h-px bg-border" />

      {/* Historical Reference & Educational Policy */}
      <div className="flex flex-col items-center gap-2 w-full max-w-sm">
        <p className="text-xs text-muted-foreground text-center leading-relaxed">
          Toggle <strong>Historical Reference</strong> and <strong>Educational Policy</strong> to overlay major historical events and policies on the timeline.
        </p>
        <div className="flex flex-wrap items-center justify-center gap-2">
          <button
            onClick={() => setShowBars((b) => !b)}
            className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 font-body text-xs font-semibold border transition-colors ${
              showBars ? 'border-purple-500/40 bg-purple-500/10 text-purple-600' : 'border-border bg-muted text-muted-foreground'
            }`}
          >
            <span className={`inline-block h-2.5 w-5 rounded-full relative transition-colors ${showBars ? 'bg-purple-500' : 'bg-border'}`}>
              <span className={`absolute top-0.5 h-1.5 w-1.5 rounded-full bg-white transition-all ${showBars ? 'left-[11px]' : 'left-[2px]'}`} />
            </span>
            Historical Reference
          </button>
          <button
            onClick={() => setShowPolicies((b) => !b)}
            className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 font-body text-xs font-semibold border transition-colors ${
              showPolicies ? 'border-pink-500/40 bg-pink-500/10 text-pink-600' : 'border-border bg-muted text-muted-foreground'
            }`}
          >
            <span className={`inline-block h-2.5 w-5 rounded-full relative transition-colors ${showPolicies ? 'bg-pink-500' : 'bg-border'}`}>
              <span className={`absolute top-0.5 h-1.5 w-1.5 rounded-full bg-white transition-all ${showPolicies ? 'left-[11px]' : 'left-[2px]'}`} />
            </span>
            Educational Policy
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── Slide 2: Zoom & pan controls ── */
function Slide2() {
  const [demoZoom, setDemoZoom] = useState(100);
  const [demoPan, setDemoPan] = useState(0);

  return (
    <div className="flex flex-col items-center gap-6 px-4">
      <h3 className="font-display text-lg font-bold text-foreground">Zoom & Navigate</h3>
      <p className="text-sm text-muted-foreground text-center max-w-sm">
        Use the zoom buttons to zoom in/out, and the arrows to pan left and right across the timeline.
      </p>

      {/* Demo controls — mirrors actual timeline control bar */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setDemoPan((p) => p + 30)}
          className="rounded-lg border border-border p-2 text-muted-foreground hover:bg-muted transition-colors"
          title="Pan left"
        >
          <ChevronLeft size={16} />
        </button>
        <button
          onClick={() => setDemoZoom((z) => Math.max(50, z - 50))}
          className="rounded-lg border border-border p-2 text-muted-foreground hover:bg-muted transition-colors"
          title="Zoom out"
        >
          <ZoomOut size={16} />
        </button>
        <motion.span
          key={demoZoom}
          initial={{ scale: 1.2 }}
          animate={{ scale: 1 }}
          className="w-16 text-center font-body text-xs text-muted-foreground"
        >
          {demoZoom}%
        </motion.span>
        <button
          onClick={() => setDemoZoom((z) => Math.min(500, z + 50))}
          className="rounded-lg border border-border p-2 text-muted-foreground hover:bg-muted transition-colors"
          title="Zoom in"
        >
          <ZoomIn size={16} />
        </button>
        <button
          onClick={() => setDemoPan((p) => p - 30)}
          className="rounded-lg border border-border p-2 text-muted-foreground hover:bg-muted transition-colors"
          title="Pan right"
        >
          <ChevronRight size={16} />
        </button>
      </div>

      {/* Animated timeline-like visualization — mirrors actual red axis */}
      <div className="relative h-28 w-64 rounded-lg border border-border bg-card overflow-hidden">
        <motion.div
          animate={{ width: `${(demoZoom / 100) * 100}%`, x: demoPan }}
          transition={{ type: 'spring', stiffness: 200, damping: 20 }}
          className="absolute inset-y-0 h-full"
          style={{ minWidth: '100%' }}
        >
          {/* Red axis line */}
          <div className="absolute left-3 right-3 top-1/2 h-[3px] bg-timeline -translate-y-1/2" />
          {/* Red arrow at end */}
          <div className="absolute right-1 top-1/2 -translate-y-1/2">
            <svg width="10" height="10" viewBox="0 0 14 14">
              <polygon points="0,0 14,7 0,14" fill="hsl(var(--penn-red))" />
            </svg>
          </div>
          {/* Year tick marks & dots on the line */}
          {[
            { x: '15%', color: 'bg-theory', label: '1950s' },
            { x: '30%', color: 'bg-edtech', label: '1970s' },
            { x: '50%', color: 'bg-tech', label: '1990s' },
            { x: '70%', color: 'bg-gentech', label: '2000s' },
            { x: '85%', color: 'bg-events', label: '2020s' },
          ].map((item, i) => (
            <div key={i} className="absolute flex flex-col items-center" style={{ left: item.x, top: '50%', transform: 'translate(-50%, -50%)' }}>
              {/* Tick mark */}
              <div className="absolute w-px h-3 bg-penn-red" style={{ top: -6 }} />
              {/* Dot on the axis */}
              <div className={`relative z-10 h-[10px] w-[10px] rounded-full ${item.color}`} />
              {/* Year label in red */}
              <span className="absolute text-[9px] font-bold font-body text-penn-red whitespace-nowrap" style={{ top: 12 }}>{item.label}</span>
            </div>
          ))}
        </motion.div>
      </div>

      <p className="text-xs text-muted-foreground text-center">
        Try the buttons above! You can also scroll to zoom on the actual timeline.
      </p>
    </div>
  );
}

/* ── Slide 3: Hover → Click to pin → Learn More ── */
function Slide3() {
  const [showTooltip, setShowTooltip] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const hideTimeout = useRef<ReturnType<typeof setTimeout>>();

  const handleMouseEnter = () => {
    clearTimeout(hideTimeout.current);
    if (!pinned && !showPopup) {
      setShowTooltip(true);
    }
  };

  const handleMouseLeave = () => {
    if (!pinned) {
      hideTimeout.current = setTimeout(() => setShowTooltip(false), 300);
    }
  };

  const handleDotClick = () => {
    if (pinned) {
      setPinned(false);
      setShowTooltip(false);
    } else {
      setPinned(true);
      setShowTooltip(true);
    }
  };

  return (
    <div className="flex flex-col items-center gap-6 px-4">
      <h3 className="font-display text-lg font-bold text-foreground">Explore Items</h3>
      <p className="text-sm text-muted-foreground text-center max-w-sm">
        Hover over a dot to preview. Click to pin the tooltip. Then click "Learn More" to open the full card.
      </p>

      {/* Demo item */}
      <div className="relative flex flex-col items-center gap-3">
        <div
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
          onClick={handleDotClick}
          className="relative cursor-pointer"
        >
          <motion.div
            animate={(showTooltip || pinned) ? { scale: 1.3, boxShadow: '0 0 16px hsl(var(--accent))' } : { scale: 1, boxShadow: '0 0 0px transparent' }}
            className="h-8 w-8 rounded-full bg-gentech border-2 border-background"
          />
          {pinned && (
            <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-penn-blue border border-background" title="Pinned" />
          )}
        </div>

        <AnimatePresence>
          {(showTooltip || pinned) && !showPopup && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              onMouseEnter={() => clearTimeout(hideTimeout.current)}
              onMouseLeave={() => { if (!pinned) { hideTimeout.current = setTimeout(() => setShowTooltip(false), 300); } }}
              className="w-52 rounded-lg border border-border bg-card p-3 shadow-lg z-10"
            >
              <p className="font-display text-sm font-bold text-foreground">WiFi</p>
              <p className="text-xs text-muted-foreground mt-1">IEEE 802.11 standard enables wireless networking.</p>
              <button
                onClick={(e) => { e.stopPropagation(); setShowPopup(true); setShowTooltip(false); setPinned(false); }}
                className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-penn-blue hover:underline"
              >
                <Search size={12} />
                Learn More
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showPopup && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="w-64 rounded-xl border-[3px] border-gentech bg-card shadow-xl overflow-hidden"
            >
              {/* Banner */}
              <div className="flex items-center justify-between px-3 py-1.5 bg-gradient-to-r from-gentech/90 to-gentech/70">
                <span className="font-display text-[10px] font-bold text-white uppercase tracking-wider">General Technology</span>
              </div>
              {/* Content */}
              <div className="p-3">
                <div className="flex items-center gap-2 mb-2">
                  <span className="inline-block h-2.5 w-2.5 rounded-full bg-gentech" />
                  <span className="font-body text-xs font-semibold text-muted-foreground">1997</span>
                </div>
                <p className="font-display text-sm font-bold text-foreground">WiFi</p>
                <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                  WiFi untethered computing from physical connections, enabling ubiquitous connectivity.
                </p>
                <button onClick={() => { setShowPopup(false); }} className="mt-2 text-xs font-semibold text-penn-blue hover:underline">Close</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {!showTooltip && !pinned && !showPopup && (
          <motion.div
            animate={{ y: [0, -4, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
            className="flex items-center gap-1 text-xs text-muted-foreground"
          >
            <MousePointer2 size={14} />
            <span>Hover over the dot</span>
          </motion.div>
        )}
      </div>
    </div>
  );
}

const slides = [Slide1, Slide2, Slide3];

export default function TutorialModal({ open, onClose }: TutorialModalProps) {
  const [current, setCurrent] = useState(0);

  const prev = () => setCurrent((c) => Math.max(0, c - 1));
  const next = () => setCurrent((c) => Math.min(slides.length - 1, c + 1));

  const SlideComponent = slides[current];

  if (!open) return null;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-md rounded-2xl border border-border bg-background p-8 shadow-2xl"
          >
            {/* Close */}
            <button
              onClick={onClose}
              className="absolute right-4 top-4 rounded-sm p-1 text-muted-foreground hover:text-foreground transition-colors"
            >
              <X size={18} />
            </button>

            {/* Slide content */}
            <div className="min-h-[320px] flex items-center justify-center">
              <AnimatePresence mode="wait">
                <motion.div
                  key={current}
                  initial={{ opacity: 0, x: 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -40 }}
                  transition={{ duration: 0.25 }}
                >
                  <SlideComponent />
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Navigation */}
            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={prev}
                disabled={current === 0}
                className="rounded-lg border border-border p-2 text-muted-foreground hover:bg-muted transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronLeft size={16} />
              </button>

              {/* Dots */}
              <div className="flex items-center gap-2">
                {slides.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrent(i)}
                    className={`h-2.5 w-2.5 rounded-full transition-all ${
                      i === current ? 'bg-penn-blue scale-125' : 'bg-border hover:bg-muted-foreground'
                    }`}
                  />
                ))}
              </div>

              <button
                onClick={next}
                disabled={current === slides.length - 1}
                className="rounded-lg border border-border p-2 text-muted-foreground hover:bg-muted transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
