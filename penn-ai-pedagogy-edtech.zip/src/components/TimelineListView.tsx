import { useMemo, useState } from 'react';
import { timelineItems, categories, CategoryType } from '@/data/timelineData';
import { ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';
import TechPokemonCard from './TechPokemonCard';
import TheoryPokemonCard from './TheoryPokemonCard';

const categoryDotColor: Record<CategoryType, string> = {
  theory: 'bg-theory',
  edtech: 'bg-tech',
  gentech: 'bg-gentech',
  challenge: 'bg-challenge',
};

type EraKey = 'all' | 'pre1950' | '1950-1979' | '1980-1999' | '2000-2014' | '2015-present';

const eras: { value: EraKey; label: string; min: number; max: number }[] = [
  { value: 'all', label: 'All Eras', min: -Infinity, max: Infinity },
  { value: 'pre1950', label: 'Pre-Digital (before 1950)', min: -Infinity, max: 1949 },
  { value: '1950-1979', label: 'Early Computing (1950–1979)', min: 1950, max: 1979 },
  { value: '1980-1999', label: 'PC & Internet (1980–1999)', min: 1980, max: 1999 },
  { value: '2000-2014', label: 'Web 2.0 (2000–2014)', min: 2000, max: 2014 },
  { value: '2015-present', label: 'AI Era (2015–present)', min: 2015, max: Infinity },
];

export default function TimelineListView() {
  const [filterCategory, setFilterCategory] = useState<CategoryType | 'all'>('all');
  const [filterEra, setFilterEra] = useState<EraKey>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    let items = filterCategory === 'all'
      ? [...timelineItems]
      : timelineItems.filter((i) => i.category === filterCategory);
    if (filterEra !== 'all') {
      const era = eras.find((e) => e.value === filterEra)!;
      items = items.filter((i) => i.year >= era.min && i.year <= era.max);
    }
    return items.sort((a, b) => a.year - b.year);
  }, [filterCategory, filterEra]);

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <label className="font-body text-sm font-semibold text-foreground">Filter by era:</label>
          <select
            value={filterEra}
            onChange={(e) => setFilterEra(e.target.value as EraKey)}
            className="rounded-md border border-input bg-background px-3 py-1.5 font-body text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          >
            {eras.map((era) => (
              <option key={era.value} value={era.value}>{era.label}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-2">
          <label className="font-body text-sm font-semibold text-foreground">Filter by category:</label>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value as CategoryType | 'all')}
            className="rounded-md border border-input bg-background px-3 py-1.5 font-body text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          >
            <option value="all">All Categories</option>
            {(Object.keys(categories) as CategoryType[]).map((cat) => (
              <option key={cat} value={cat}>{categories[cat].label}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="space-y-1">
        {filtered.map((item) => {
          const cat = categories[item.category];
          const isExpanded = expandedId === item.id;
          const isTech = item.category === 'edtech' || item.category === 'gentech';
          const isTheory = item.category === 'theory';

          return (
            <div
              key={item.id}
              className="rounded-lg border border-border bg-card transition-colors hover:bg-muted/50"
            >
              <button
                onClick={() => setExpandedId(isExpanded ? null : item.id)}
                className="flex w-full items-center gap-3 px-4 py-3 text-left"
              >
                <span className={`h-3 w-3 flex-shrink-0 rounded-full ${categoryDotColor[item.category]}`} />
                <span className="font-body text-sm font-bold text-foreground w-12 flex-shrink-0">{item.year}</span>
                <span className="font-body text-sm font-semibold text-foreground flex-1">{item.label}</span>
                <span className={`font-body text-xs ${cat.colorClass} hidden sm:inline`}>{cat.label}</span>
                {isExpanded ? <ChevronUp size={14} className="text-muted-foreground" /> : <ChevronDown size={14} className="text-muted-foreground" />}
              </button>

              {isExpanded && (
                <div className="border-t border-border px-4 py-3 pl-12">
                  {isTech ? (
                    <div className="py-2">
                      <TechPokemonCard item={item} compact />
                    </div>
                  ) : isTheory ? (
                    <div className="py-2">
                      <TheoryPokemonCard item={item} compact />
                    </div>
                  ) : (
                    <>
                      <p className="font-body text-sm text-muted-foreground mb-1">{item.brief}</p>
                      <p className="font-body text-sm text-foreground">{item.detail}</p>
                      {item.sources && item.sources.length > 0 && (
                        <div className="mt-2 space-y-1">
                          {item.sources.map((s, i) => (
                            <a
                              key={i}
                              href={s.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-1 font-body text-xs text-penn-blue hover:underline"
                            >
                              <ExternalLink size={10} />
                              {s.label}
                            </a>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
