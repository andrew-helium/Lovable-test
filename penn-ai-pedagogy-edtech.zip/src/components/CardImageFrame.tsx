import { useMemo, useState, useCallback } from 'react';

interface CardImageFrameProps {
  alt: string;
  compact?: boolean;
  fallback: React.ReactNode;
  imageUrl?: string;
  borderClass: string;
}

const THUMBNAIL_SIZES = ['440px-', '800px-', '220px-', '3840px-'] as const;

function buildImageCandidates(url?: string) {
  if (!url) return [];
  const urls = [url];

  for (const size of THUMBNAIL_SIZES) {
    if (url.includes(size)) {
      for (const candidate of THUMBNAIL_SIZES) {
        if (candidate !== size) {
          urls.push(url.replace(size, candidate));
        }
      }
      break;
    }
  }

  return Array.from(new Set(urls));
}

export default function CardImageFrame({ alt, compact = false, fallback, imageUrl, borderClass }: CardImageFrameProps) {
  const candidates = useMemo(() => buildImageCandidates(imageUrl), [imageUrl]);
  const [candidateIndex, setCandidateIndex] = useState(0);
  const [hasFailed, setHasFailed] = useState(candidates.length === 0);

  const currentSrc = candidates[candidateIndex];
  const frameHeight = compact ? 'h-36' : 'h-48';

  const handleError = useCallback(() => {
    const nextIndex = candidateIndex + 1;
    if (nextIndex < candidates.length) {
      setCandidateIndex(nextIndex);
      return;
    }
    setHasFailed(true);
  }, [candidateIndex, candidates.length]);

  return (
    <div className={`mx-3 mt-3 overflow-hidden rounded-lg border-2 ${borderClass} bg-white`}>
      {!hasFailed && currentSrc ? (
        <img
          key={currentSrc}
          src={currentSrc}
          alt={alt}
          className={`w-full bg-white object-cover ${frameHeight}`}
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onError={handleError}
        />
      ) : (
        <div className={`flex items-center justify-center bg-muted ${frameHeight}`}>
          {fallback}
        </div>
      )}
    </div>
  );
}
