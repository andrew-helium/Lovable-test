import { TimelineItem } from '@/data/timelineData';
import { X, ExternalLink, BookOpen } from 'lucide-react';
import CardImageFrame from './CardImageFrame';

interface TheoryPokemonCardProps {
  item: TimelineItem;
  onClose?: () => void;
  compact?: boolean;
}

export default function TheoryPokemonCard({ item, onClose, compact = false }: TheoryPokemonCardProps) {
  return (
    <div
      className={`relative overflow-hidden rounded-2xl border-[3px] border-theory shadow-xl ${
        compact ? 'max-w-sm' : 'w-full max-w-md'
      }`}
      style={{
        background: 'linear-gradient(135deg, hsl(145 40% 92%), hsl(150 45% 96%), hsl(145 40% 92%))',
      }}
    >
      {/* Top banner */}
      <div className="flex items-center justify-between px-4 py-2 bg-gradient-to-r from-theory/90 to-theory/70">
        <span className="font-display text-xs font-bold text-white uppercase tracking-wider opacity-90">
          Learning Theory
        </span>
        <div className="flex items-center gap-1.5">
          <BookOpen size={12} className="text-white" />
          <span className="font-body text-xs font-bold text-white">{item.year}</span>
        </div>
        {!compact && onClose && (
          <button
            onClick={onClose}
            className="rounded-full p-0.5 hover:bg-white/20 transition-colors"
          >
            <X size={16} className="text-white" />
          </button>
        )}
      </div>

      <CardImageFrame
        imageUrl={item.imageUrl}
        alt={item.scholar || item.label}
        compact={compact}
        borderClass="border-theory/40"
        fallback={<BookOpen size={48} className="text-muted-foreground/30" />}
      />

      {/* Scholar name */}
      {item.scholar && (
        <div className="mx-3 mt-1 px-1">
          <p className="font-body text-[10px] font-semibold text-theory uppercase tracking-wider">
            {item.scholar}
          </p>
        </div>
      )}

      {/* Name plate */}
      <div className="mx-3 mt-1 rounded-lg bg-gradient-to-r from-theory/20 to-theory/10 px-3 py-1.5">
        <h3 className={`font-display font-bold text-foreground ${compact ? 'text-base' : 'text-lg'}`}>
          {item.label}
        </h3>
      </div>

      {/* Description */}
      <div className="mx-3 mt-2 px-1">
        <p className={`font-body text-foreground/80 leading-relaxed ${compact ? 'text-xs' : 'text-sm'}`}>
          {compact ? item.brief : item.detail}
        </p>
      </div>

      {/* Related Tags */}
      {item.relatedTags && item.relatedTags.length > 0 && (
        <div className="mx-3 mt-3 rounded-lg border border-border bg-card/60 p-2.5">
          <p className="font-body text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1.5">
            Related
          </p>
          <div className="flex flex-wrap gap-1.5">
            {item.relatedTags.map((tag) => {
              const isChallenge = [
                'Knowledge Distribution & Classification',
                'Natural Disasters / Disruptions',
                'Lack of Standardized Assessment',
                'Cognitive Overload',
                'Transfer of Learning',
                'Shortened Distributed Attention',
                'COVID-19 Pandemic',
              ].includes(tag);
              return (
                <span
                  key={tag}
                  className={`inline-flex items-center rounded-full px-2 py-0.5 font-body text-[10px] font-semibold border ${
                    isChallenge
                      ? 'border-challenge/30 bg-challenge-light text-challenge'
                      : 'border-theory/30 bg-theory-light text-theory'
                  }`}
                >
                  {tag}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* Academic Article */}
      {item.academicArticle && (
        <div className="mx-3 mt-2 mb-3 rounded-lg border border-border bg-card/60 p-2.5">
          <p className="font-body text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">
            Key Research
          </p>
          <a
            href={item.academicArticle.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-start gap-1.5 font-body text-xs text-penn-blue-light hover:underline leading-snug"
          >
            <ExternalLink size={10} className="mt-0.5 flex-shrink-0" />
            {item.academicArticle.label}
          </a>
        </div>
      )}

      {/* Bottom decorative bar */}
      <div className="h-1.5 bg-gradient-to-r from-theory/60 via-theory to-theory/60" />
    </div>
  );
}
