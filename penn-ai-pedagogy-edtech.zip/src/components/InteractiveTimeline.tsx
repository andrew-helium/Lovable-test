import { useState, useRef, useMemo, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { timelineItems, categories, CategoryType, TimelineItem, historicalPeriods, educationalPolicies, HistoricalPeriod } from '@/data/timelineData';
import TimelineTooltip from './TimelineTooltip';
import { ZoomIn, ZoomOut, RotateCcw, X, ExternalLink, ChevronLeft, ChevronRight, HelpCircle } from 'lucide-react';
import TutorialModal from './TutorialModal';

const MIN_ZOOM = 0.5;
const MAX_ZOOM = 8;
const ZOOM_STEP = 0.5;
const DEFAULT_ZOOM = 1;

const CANVAS_H = 620;
const AXIS_Y_PX = CANVAS_H * 0.70;
const SIDE_PADDING_PX = 40;
const FALLBACK_VIEWPORT_W = 960;

const categoryOrder: CategoryType[] = ['theory', 'edtech', 'gentech', 'challenge'];

type EraKey = 'all' | 'pre1950' | '1950-1979' | '1980-1999' | '2000-2014' | '2015-present';
const eras: { value: EraKey; label: string; min: number; max: number }[] = [
  { value: 'all', label: 'All Eras', min: -Infinity, max: Infinity },
  { value: 'pre1950', label: 'Pre-Digital (before 1950)', min: -Infinity, max: 1949 },
  { value: '1950-1979', label: 'Early Computing (1950–1979)', min: 1950, max: 1979 },
  { value: '1980-1999', label: 'PC & Internet (1980–1999)', min: 1980, max: 1999 },
  { value: '2000-2014', label: 'Web 2.0 (2000–2014)', min: 2000, max: 2014 },
  { value: '2015-present', label: 'AI Era (2015–present)', min: 2015, max: Infinity },
];

const categoryDotColor: Record<CategoryType, string> = {
  theory: 'hsl(var(--theory-green))',
  edtech: 'hsl(var(--tech-amber))',
  gentech: 'hsl(var(--gentech-blue))',
  challenge: 'hsl(var(--challenge-red))',
};

interface Props {
  extraItems?: TimelineItem[];
  playIntro?: boolean;
}

export default function InteractiveTimeline({ extraItems = [], playIntro = false }: Props) {
  const [zoom, setZoom] = useState(DEFAULT_ZOOM);
  const [panX, setPanX] = useState(0);
  const [isPanning, setIsPanning] = useState(false);
  const [containerWidth, setContainerWidth] = useState(FALLBACK_VIEWPORT_W);
  const [activeCategories, setActiveCategories] = useState<Set<CategoryType>>(
    playIntro ? new Set() : new Set(categoryOrder)
  );
  const [selectedPeriod, setSelectedPeriod] = useState<HistoricalPeriod | null>(null);
  const [showPeriods, setShowPeriods] = useState(!playIntro);
  const [showPolicies, setShowPolicies] = useState(!playIntro);

  const [showTutorial, setShowTutorial] = useState(false);

  // Intro animation: reveal categories one by one, then toggle Historical Reference + Educational Policy
  useEffect(() => {
    if (!playIntro) return;
    // Reset to empty state at the start of the intro
    setActiveCategories(new Set());
    setShowPeriods(false);
    setShowPolicies(false);
    const timeouts: ReturnType<typeof setTimeout>[] = [];
    const STEP = 1600; // 0.5x speed (was 800)
    let t = 800;
    categoryOrder.forEach((cat) => {
      timeouts.push(setTimeout(() => {
        setActiveCategories((prev) => {
          const next = new Set(prev);
          next.add(cat);
          return next;
        });
      }, t));
      t += STEP;
    });
    t += 600;
    // Historical Reference: on / off / on
    timeouts.push(setTimeout(() => setShowPeriods(true), t)); t += STEP;
    timeouts.push(setTimeout(() => setShowPeriods(false), t)); t += STEP;
    timeouts.push(setTimeout(() => setShowPeriods(true), t)); t += STEP;
    // Educational Policy: on / off / on
    timeouts.push(setTimeout(() => setShowPolicies(true), t)); t += STEP;
    timeouts.push(setTimeout(() => setShowPolicies(false), t)); t += STEP;
    timeouts.push(setTimeout(() => setShowPolicies(true), t)); t += STEP;
    // Open tutorial after intro completes
    timeouts.push(setTimeout(() => setShowTutorial(true), t + 400));
    return () => { timeouts.forEach(clearTimeout); };
  }, [playIntro]);
  const [filterEra, setFilterEra] = useState<EraKey>('all');
  const panStartRef = useRef({ x: 0, panX: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  const sortedItems = useMemo(
    () => [...timelineItems, ...extraItems].sort((a, b) => a.year - b.year),
    [extraItems]
  );

  const minYear = sortedItems[0]?.year ?? 1800;
  const maxYear = sortedItems[sortedItems.length - 1]?.year ?? 2025;
  const totalWidth = Math.max(containerWidth, containerWidth * zoom);

  const clampPan = useCallback(
    (nextPan: number, nextZoom = zoom, viewportWidth = containerWidth) => {
      const contentWidth = Math.max(viewportWidth, viewportWidth * nextZoom);
      const minPan = Math.min(0, viewportWidth - contentWidth);
      return Math.max(minPan, Math.min(0, nextPan));
    },
    [containerWidth, zoom]
  );

  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;
    const updateWidth = () => setContainerWidth(node.clientWidth || FALLBACK_VIEWPORT_W);
    updateWidth();
    const observer = new ResizeObserver(() => updateWidth());
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    setPanX((currentPan) => clampPan(currentPan));
  }, [clampPan]);

  // Auto-zoom/pan only when era filter selection changes
  const prevEraRef = useRef(filterEra);
  useEffect(() => {
    if (prevEraRef.current === filterEra) return;
    prevEraRef.current = filterEra;
    if (filterEra === 'all') {
      setZoom(DEFAULT_ZOOM);
      setPanX(0);
      return;
    }
    const era = eras.find((e) => e.value === filterEra);
    if (!era) return;
    const eraMin = Math.max(era.min, minYear);
    const eraMax = Math.min(era.max, maxYear);
    const yearRange = maxYear - minYear || 1;
    const eraSpan = eraMax - eraMin || 1;
    const newZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, (yearRange / eraSpan) * 0.8));
    const newTotalWidth = Math.max(containerWidth, containerWidth * newZoom);
    const usable = Math.max(newTotalWidth - SIDE_PADDING_PX * 2, 1);
    const eraCenterYear = (eraMin + eraMax) / 2;
    const eraCenterPx = SIDE_PADDING_PX + ((eraCenterYear - minYear) / yearRange) * usable;
    const contentWidth = newTotalWidth;
    const minPan = Math.min(0, containerWidth - contentWidth);
    const newPan = Math.max(minPan, Math.min(0, -(eraCenterPx - containerWidth / 2)));
    setZoom(newZoom);
    setPanX(newPan);
  }, [filterEra, minYear, maxYear, containerWidth]);

  const yearToPosition = useCallback(
    (year: number) => {
      const range = maxYear - minYear || 1;
      const usable = Math.max(totalWidth - SIDE_PADDING_PX * 2, 1);
      return SIDE_PADDING_PX + ((year - minYear) / range) * usable;
    },
    [maxYear, minYear, totalWidth]
  );

  const handleZoom = useCallback((dir: number) => {
    setZoom((prevZoom) => {
      const nextZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, prevZoom + dir * ZOOM_STEP));
      if (nextZoom === prevZoom) return prevZoom;
      const prevTotalWidth = Math.max(containerWidth, containerWidth * prevZoom);
      const nextTotalWidth = Math.max(containerWidth, containerWidth * nextZoom);
      setPanX((prevPan) => {
        const viewportCenter = -prevPan + containerWidth / 2;
        const centerRatio = prevTotalWidth > 0 ? viewportCenter / prevTotalWidth : 0.5;
        const contentWidth = nextTotalWidth;
        const minPan = Math.min(0, containerWidth - contentWidth);
        return Math.max(minPan, Math.min(0, -(centerRatio * nextTotalWidth - containerWidth / 2)));
      });
      return nextZoom;
    });
  }, [containerWidth]);

  const handleWheel = (e: React.WheelEvent) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      handleZoom(e.deltaY < 0 ? 1 : -1);
    } else {
      setPanX((p) => clampPan(p - e.deltaX - e.deltaY));
    }
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsPanning(true);
    panStartRef.current = { x: e.clientX, panX };
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };
  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isPanning) return;
    setPanX(clampPan(panStartRef.current.panX + (e.clientX - panStartRef.current.x)));
  };
  const handlePointerUp = () => setIsPanning(false);

  const toggleCategory = (cat: CategoryType) => {
    setActiveCategories((prev) => {
      const next = new Set(prev);
      if (next.has(cat)) next.delete(cat);
      else next.add(cat);
      return next;
    });
  };

  const decades = useMemo(() => {
    const arr: number[] = [];
    const start = Math.floor(minYear / 10) * 10;
    const end = Math.ceil(maxYear / 10) * 10;
    for (let y = start; y <= end; y += 10) arr.push(y);
    return arr;
  }, [minYear, maxYear]);

  const visibleItems = useMemo(() => {
    let items = sortedItems.filter((i) => activeCategories.has(i.category));
    if (filterEra !== 'all') {
      const era = eras.find((e) => e.value === filterEra)!;
      items = items.filter((i) => i.year >= era.min && i.year <= era.max);
    }
    return items;
  }, [sortedItems, activeCategories, filterEra]);

  const positionedItems = useMemo(() => {
    const placed: { x: number; stemPx: number }[] = [];
    const baseStem = 30;
    const stemStep = 42;
    const minXGapPx = Math.max(56, 104 / zoom);

    return visibleItems.map((item, idx) => {
      const x = yearToPosition(item.year);
      let stemPx = baseStem;
      let attempts = 0;
      while (attempts < 10) {
        const conflict = placed.some(
          (p) => Math.abs(p.x - x) < minXGapPx && Math.abs(p.stemPx - stemPx) < stemStep
        );
        if (!conflict) break;
        stemPx += stemStep;
        attempts++;
      }
      placed.push({ x, stemPx });
      return { item, x, stemPx, idx };
    });
  }, [visibleItems, yearToPosition, zoom]);

  const periodRows = useMemo(() => {
    const allPeriods = [
      ...(showPeriods ? historicalPeriods : []),
      ...(showPolicies ? educationalPolicies : []),
    ];
    const rows: { period: typeof allPeriods[0]; row: number }[] = [];
    const occupied: { startX: number; endX: number; row: number }[] = [];
    for (const period of allPeriods) {
      const startX = yearToPosition(Math.max(period.startYear, minYear));
      const endX = yearToPosition(Math.min(period.endYear, maxYear));
      let row = 0;
      while (occupied.some((o) => o.row === row && o.startX < endX && o.endX > startX)) {
        row++;
      }
      occupied.push({ startX, endX, row });
      rows.push({ period, row });
    }
    return rows;
  }, [yearToPosition, minYear, maxYear, showPeriods, showPolicies]);

  const PERIOD_BAR_TOP = AXIS_Y_PX + 30;
  const PERIOD_BAR_H = 18;
  const PERIOD_BAR_GAP = 4;

  const textColorMap: Record<CategoryType, string> = {
    theory: 'text-theory',
    edtech: 'text-tech',
    gentech: 'text-gentech',
    challenge: 'text-challenge',
  };

  return (
    <div className="w-full">
      {/* Category legend/filter */}
      <div className="mb-6 flex flex-wrap items-center justify-center gap-4">
        {categoryOrder.map((cat) => {
          const c = categories[cat];
          const active = activeCategories.has(cat);
          const borderColorMap: Record<CategoryType, string> = {
            theory: 'border-theory/40',
            edtech: 'border-tech/40',
            gentech: 'border-gentech/40',
            challenge: 'border-challenge/40',
          };
          const bgColorMap: Record<CategoryType, string> = {
            theory: 'bg-theory/10',
            edtech: 'bg-tech/10',
            gentech: 'bg-gentech/10',
            challenge: 'bg-challenge/10',
          };
          return (
            <button
              key={cat}
              onClick={() => toggleCategory(cat)}
              className={`inline-flex items-center gap-2 px-4 py-2 rounded-full border transition-all ${
                active
                  ? `${borderColorMap[cat]} ${bgColorMap[cat]} opacity-100`
                  : 'border-border bg-muted opacity-40'
              }`}
            >
              <span
                className="inline-block h-3 w-3 rounded-full flex-shrink-0"
                style={{ backgroundColor: categoryDotColor[cat] }}
              />
              <span className={`font-body text-sm font-medium ${active ? c.colorClass : 'text-muted-foreground'}`}>
                {c.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Controls row */}
      <div className="mb-4 flex items-center justify-center gap-4">
        <div className="flex items-center gap-2">
          <button onClick={() => setPanX((p) => clampPan(p + 200))} className="rounded-lg border border-border p-2 text-muted-foreground hover:bg-muted transition-colors" title="Pan left"><ChevronLeft size={16} /></button>
          <button onClick={() => handleZoom(-1)} className="rounded-lg border border-border p-2 text-muted-foreground hover:bg-muted transition-colors" title="Zoom out"><ZoomOut size={16} /></button>
          <span className="w-16 text-center font-body text-xs text-muted-foreground">{Math.round(zoom * 100)}%</span>
          <button onClick={() => handleZoom(1)} className="rounded-lg border border-border p-2 text-muted-foreground hover:bg-muted transition-colors" title="Zoom in"><ZoomIn size={16} /></button>
          <button onClick={() => setPanX((p) => clampPan(p - 200))} className="rounded-lg border border-border p-2 text-muted-foreground hover:bg-muted transition-colors" title="Pan right"><ChevronRight size={16} /></button>
          <button onClick={() => { setZoom(DEFAULT_ZOOM); setPanX(0); }} className="rounded-lg border border-border p-2 text-muted-foreground hover:bg-muted transition-colors" title="Reset"><RotateCcw size={16} /></button>
        </div>
        <div className="h-5 w-px bg-border" />
        <select
          value={filterEra}
          onChange={(e) => setFilterEra(e.target.value as EraKey)}
          className="rounded-full border border-border bg-muted px-3 py-1.5 font-body text-xs font-semibold text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring"
        >
          {eras.map((era) => (
            <option key={era.value} value={era.value}>{era.label}</option>
          ))}
        </select>
        <button
          onClick={() => { setShowPeriods((p) => !p); if (!showPeriods === false) setSelectedPeriod(null); }}
          className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 font-body text-xs font-semibold border transition-colors ${showPeriods ? 'border-purple-500/40 bg-purple-500/10 text-purple-600' : 'border-border bg-muted text-muted-foreground'}`}
        >
          <span className={`inline-block h-2.5 w-5 rounded-full relative transition-colors ${showPeriods ? 'bg-purple-500' : 'bg-border'}`}>
            <span className={`absolute top-0.5 h-1.5 w-1.5 rounded-full bg-white transition-all ${showPeriods ? 'left-[11px]' : 'left-[2px]'}`} />
          </span>
          Historical Reference
        </button>
        <button
          onClick={() => { setShowPolicies((p) => !p); if (!showPolicies === false) setSelectedPeriod(null); }}
          className={`inline-flex items-center gap-2 rounded-full px-3 py-1.5 font-body text-xs font-semibold border transition-colors ${showPolicies ? 'border-pink-500/40 bg-pink-500/10 text-pink-600' : 'border-border bg-muted text-muted-foreground'}`}
        >
          <span className={`inline-block h-2.5 w-5 rounded-full relative transition-colors ${showPolicies ? 'bg-pink-500' : 'bg-border'}`}>
            <span className={`absolute top-0.5 h-1.5 w-1.5 rounded-full bg-white transition-all ${showPolicies ? 'left-[11px]' : 'left-[2px]'}`} />
          </span>
          Educational Policy
        </button>
        <button
          onClick={() => setShowTutorial(true)}
          className="inline-flex items-center gap-2 rounded-full px-3 py-1.5 font-body text-xs font-semibold border border-border bg-muted text-muted-foreground hover:bg-accent hover:text-accent-foreground transition-colors"
        >
          <HelpCircle size={14} />
          Tutorial
        </button>
      </div>

      <TutorialModal open={showTutorial} onClose={() => setShowTutorial(false)} />

      {/* Timeline canvas */}
      <div
        ref={containerRef}
        className="relative overflow-hidden rounded-xl border border-border bg-card shadow-sm"
        style={{ height: CANVAS_H, cursor: isPanning ? 'grabbing' : 'grab' }}
        onWheel={handleWheel}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
      >
        <div
          className="relative h-full"
          style={{
            width: `${totalWidth}px`,
            transform: `translateX(${panX}px)`,
            transition: isPanning ? 'none' : 'transform 0.15s ease-out',
          }}
        >
          {decades.map((d) => (
            <div
              key={`g-${d}`}
              className="absolute border-l border-border/15"
              style={{ left: `${yearToPosition(d)}px`, top: 0, bottom: `${CANVAS_H - AXIS_Y_PX}px` }}
            />
          ))}

          {/* RED AXIS LINE */}
          <div
            className="absolute bg-timeline"
            style={{
              top: AXIS_Y_PX,
              left: `${yearToPosition(minYear)}px`,
              width: `${yearToPosition(maxYear) - yearToPosition(minYear)}px`,
              height: 3,
              transform: 'translateY(-50%)',
            }}
          />

          <div className="absolute" style={{ top: AXIS_Y_PX, left: `${yearToPosition(maxYear) + 2}px`, transform: 'translateY(-50%)' }}>
            <svg width="14" height="14" viewBox="0 0 14 14">
              <polygon points="0,0 14,7 0,14" fill="hsl(var(--penn-red))" />
            </svg>
          </div>

          {decades.map((d) => (
            <div key={d} className="absolute" style={{ left: `${yearToPosition(d)}px`, top: AXIS_Y_PX, transform: 'translateY(-50%)' }}>
              <div className="absolute left-0 w-px bg-penn-red" style={{ height: 14, top: -7 }} />
              <span className="absolute left-1/2 -translate-x-1/2 whitespace-nowrap font-body text-[11px] font-bold text-penn-red" style={{ top: 14 }}>
                {d === decades[0] ? `${d}` : `${d}s`}
              </span>
            </div>
          ))}

          {/* HISTORICAL PERIOD & POLICY BARS */}
          <AnimatePresence>
            {(showPeriods || showPolicies) && periodRows.map(({ period, row }) => {
              const x1 = yearToPosition(Math.max(period.startYear, minYear));
              const x2 = yearToPosition(Math.min(period.endYear, maxYear));
              const top = PERIOD_BAR_TOP + row * (PERIOD_BAR_H + PERIOD_BAR_GAP);
              return (
                <motion.div
                  key={period.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: selectedPeriod?.id === period.id ? 1 : 0.75 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5, ease: 'easeInOut' }}
                  className="absolute rounded-sm flex items-center justify-center overflow-hidden cursor-pointer hover:opacity-100"
                  style={{ left: x1, width: Math.max(x2 - x1, 4), top, height: PERIOD_BAR_H, backgroundColor: period.color }}
                  onClick={(e) => { e.stopPropagation(); setSelectedPeriod(period); }}
                  title={`${period.label} (${period.startYear}–${period.endYear}) — Click to learn more`}
                >
                  <span className="font-body text-[9px] font-bold text-white whitespace-nowrap px-1 truncate">{period.label}</span>
                </motion.div>
              );
            })}
          </AnimatePresence>

          {/* ITEMS */}
          <AnimatePresence>
            {positionedItems.map(({ item, x, stemPx, idx }) => {
              const dotColor = categoryDotColor[item.category];
              const textColorClass = textColorMap[item.category] || 'text-penn-red';

              return (
                <TimelineTooltip key={item.id} item={item}>
                  <motion.div
                    className="absolute group"
                    style={{ left: `${x}px`, top: AXIS_Y_PX - 13, transform: 'translate(-50%, -100%)' }}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.5, ease: 'easeInOut', delay: idx * 0.01 }}
                  >
                    <div
                      className="relative z-10 cursor-pointer transition-transform group-hover:scale-150"
                      style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: dotColor }}
                    />
                    <div className="absolute bg-border" style={{ width: 1, left: 4.5, bottom: 10, height: stemPx }} />
                    <div
                      className={`absolute text-center font-body text-[11px] font-semibold leading-tight cursor-pointer ${textColorClass}`}
                      style={{ width: 110, left: -50, bottom: stemPx + 12 }}
                    >
                      {item.label}
                    </div>
                  </motion.div>
                </TimelineTooltip>
              );
            })}
          </AnimatePresence>
        </div>
      </div>

      {/* Historical Period Detail Panel */}
      <AnimatePresence>
        {selectedPeriod && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mt-4 rounded-xl border border-border bg-card p-5 shadow-md relative"
          >
            <button
              onClick={() => setSelectedPeriod(null)}
              className="absolute top-3 right-3 rounded-full p-1 text-muted-foreground hover:bg-muted transition-colors"
            >
              <X size={16} />
            </button>
            <div className="flex items-center gap-3 mb-3">
              <span className="inline-block h-4 w-4 rounded-sm" style={{ backgroundColor: selectedPeriod.color }} />
              <h3 className="font-display text-lg font-bold text-foreground">
                {selectedPeriod.label}
                <span className="ml-2 font-body text-sm font-normal text-muted-foreground">
                  ({selectedPeriod.startYear}–{selectedPeriod.endYear})
                </span>
              </h3>
            </div>
            <p className="font-body text-sm text-muted-foreground leading-relaxed mb-3">
              {selectedPeriod.description}
            </p>
            <a
              href={selectedPeriod.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 font-body text-sm font-semibold text-penn-blue hover:underline"
            >
              {selectedPeriod.sourceLabel} <ExternalLink size={14} />
            </a>
          </motion.div>
        )}
      </AnimatePresence>

      <p className="mt-3 text-center font-body text-xs text-muted-foreground">
        Scroll to pan · Ctrl+Scroll to zoom · Click a dot for details · Click a period bar to learn more
      </p>
    </div>
  );
}
