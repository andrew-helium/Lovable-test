import { useState, useRef } from 'react';
import { createPortal } from 'react-dom';
import { CategoryType, categories, timelineItems, TimelineItem } from '@/data/timelineData';
import { Plus, BookOpen, Zap, Cpu, AlertTriangle, Pencil, Check, X } from 'lucide-react';
import { toast } from 'sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import FieldHelp from './FieldHelp';
import MiniPokemonCard from './MiniPokemonCard';

interface TimelineItemFormProps {
  onSubmit: (item: {
    label: string;
    year: number;
    category: CategoryType;
    brief: string;
    detail: string;
    sourceLabel?: string;
    sourceUrl?: string;
    imageUrl?: string;
    relatedTags?: string[];
    academicArticleLabel?: string;
    academicArticleUrl?: string;
    scholar?: string;
  }) => void;
}

const itemsByLabel = new Map<string, TimelineItem>(
  timelineItems.map((i) => [i.label, i])
);
const allTimelineLabels = timelineItems.map((i) => i.label);

const categoryConfig: Record<CategoryType, {
  gradient: string;
  border: string;
  banner: string;
  namePlate: string;
  bottomBar: string;
  imgBorder: string;
  typeLabel: string;
  icon: typeof BookOpen;
}> = {
  theory: {
    gradient: 'linear-gradient(135deg, hsl(145 40% 92%), hsl(150 45% 96%), hsl(145 40% 92%))',
    border: 'border-theory',
    banner: 'bg-gradient-to-r from-theory/90 to-theory/70',
    namePlate: 'bg-gradient-to-r from-theory/20 to-theory/10',
    bottomBar: 'bg-gradient-to-r from-theory/60 via-theory to-theory/60',
    imgBorder: 'border-theory/40',
    typeLabel: 'Learning Theory',
    icon: BookOpen,
  },
  edtech: {
    gradient: 'linear-gradient(135deg, hsl(40 80% 94%), hsl(45 90% 97%), hsl(40 80% 94%))',
    border: 'border-tech',
    banner: 'bg-gradient-to-r from-tech/90 to-tech/70',
    namePlate: 'bg-gradient-to-r from-tech/20 to-tech/10',
    bottomBar: 'bg-gradient-to-r from-tech/60 via-tech to-tech/60',
    imgBorder: 'border-tech/40',
    typeLabel: 'Educational Technology',
    icon: Zap,
  },
  gentech: {
    gradient: 'linear-gradient(135deg, hsl(210 55% 93%), hsl(215 50% 96%), hsl(210 55% 93%))',
    border: 'border-gentech',
    banner: 'bg-gradient-to-r from-gentech/90 to-gentech/70',
    namePlate: 'bg-gradient-to-r from-gentech/20 to-gentech/10',
    bottomBar: 'bg-gradient-to-r from-gentech/60 via-gentech to-gentech/60',
    imgBorder: 'border-gentech/40',
    typeLabel: 'General Technology',
    icon: Cpu,
  },
  challenge: {
    gradient: 'linear-gradient(135deg, hsl(0 40% 94%), hsl(0 45% 97%), hsl(0 40% 94%))',
    border: 'border-challenge',
    banner: 'bg-gradient-to-r from-challenge/90 to-challenge/70',
    namePlate: 'bg-gradient-to-r from-challenge/20 to-challenge/10',
    bottomBar: 'bg-gradient-to-r from-challenge/60 via-challenge to-challenge/60',
    imgBorder: 'border-challenge/40',
    typeLabel: 'Instructional Challenge',
    icon: AlertTriangle,
  },
};

type EditField = 'label' | 'year' | 'brief' | 'detail' | 'scholar' | 'imageUrl' | 'academicLabel' | 'academicUrl' | null;

const HELP_TEXT = {
  year: 'The year this item was introduced, published, or first widely adopted. Use a single year (e.g. 1960).',
  label: 'The official name of the technology, theory, or challenge as it is most commonly known.',
  scholar: 'The primary scholar(s) credited with developing this learning theory.',
  brief: 'A one-sentence summary (about 10–20 words). This is what shows up on the timeline tooltip — keep it punchy.',
  detail: 'A fuller paragraph (2–4 sentences) explaining context, significance, and what makes this item important to ed-tech history.',
  image: 'A direct link to a public image (Wikipedia Commons works well). Right-click an image and copy its image address.',
  related: 'Connect this item to existing timeline items it relates to. Hover any option to preview its card.',
  academic: 'A peer-reviewed article, book chapter, or scholarly source supporting this entry. Include full citation and a DOI/URL.',
};

export default function TimelineItemForm({ onSubmit }: TimelineItemFormProps) {
  const [category, setCategory] = useState<CategoryType>('theory');
  const [label, setLabel] = useState('');
  const [year, setYear] = useState('');
  const [brief, setBrief] = useState('');
  const [detail, setDetail] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [scholar, setScholar] = useState('');
  const [academicLabel, setAcademicLabel] = useState('');
  const [academicUrl, setAcademicUrl] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [editingField, setEditingField] = useState<EditField>(null);
  const [showRelatedDropdown, setShowRelatedDropdown] = useState(false);
  const [hoveredRelated, setHoveredRelated] = useState<string | null>(null);
  const [hoverPos, setHoverPos] = useState<{ bottom: number; left: number }>({ bottom: 0, left: 0 });
  const inputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const relatedBoxRef = useRef<HTMLDivElement>(null);

  const config = categoryConfig[category];
  const Icon = config.icon;

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = () => {
    if (!label.trim()) {
      toast.error('Please at least provide a Name for the item.');
      return;
    }
    onSubmit({
      label: label.trim(),
      year: year ? parseInt(year, 10) : new Date().getFullYear(),
      category,
      brief: brief.trim(),
      detail: detail.trim(),
      imageUrl: imageUrl || undefined,
      relatedTags: selectedTags.length > 0 ? selectedTags : undefined,
      academicArticleLabel: academicLabel || undefined,
      academicArticleUrl: academicUrl || undefined,
      scholar: category === 'theory' ? scholar || undefined : undefined,
    });
    toast.success(`"${label}" added to the timeline!`);
    setLabel('');
    setYear('');
    setBrief('');
    setDetail('');
    setImageUrl('');
    setScholar('');
    setAcademicLabel('');
    setAcademicUrl('');
    setSelectedTags([]);
    setEditingField(null);
  };

  const EditableText = ({
    field,
    value,
    setValue,
    placeholder,
    className,
    multiline = false,
  }: {
    field: EditField;
    value: string;
    setValue: (v: string) => void;
    placeholder: string;
    className?: string;
    multiline?: boolean;
  }) => {
    const isEditing = editingField === field;

    if (isEditing) {
      if (multiline) {
        return (
          <div className="flex items-start gap-1">
            <textarea
              ref={textareaRef}
              autoFocus
              value={value}
              onChange={(e) => setValue(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); setEditingField(null); } }}
              placeholder={placeholder}
              rows={3}
              className={`${className} w-full resize-none rounded border border-input bg-background px-2 py-1 focus:outline-none focus:ring-1 focus:ring-ring`}
            />
            <button onClick={() => setEditingField(null)} className="mt-1 rounded p-0.5 hover:bg-muted"><Check size={12} /></button>
          </div>
        );
      }
      return (
        <div className="flex items-center gap-1">
          <input
            ref={inputRef}
            autoFocus
            type={field === 'year' ? 'number' : 'text'}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') setEditingField(null); }}
            placeholder={placeholder}
            className={`${className} w-full rounded border border-input bg-background px-2 py-1 focus:outline-none focus:ring-1 focus:ring-ring`}
          />
          <button onClick={() => setEditingField(null)} className="rounded p-0.5 hover:bg-muted"><Check size={12} /></button>
        </div>
      );
    }

    return (
      <button
        onClick={() => setEditingField(field)}
        className={`${className} group flex items-center gap-1.5 text-left hover:bg-foreground/5 rounded px-1 py-0.5 transition-colors w-full`}
      >
        <span className={value ? '' : 'text-muted-foreground/60 italic'}>
          {value || placeholder}
        </span>
        <Pencil size={10} className="text-muted-foreground/40 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
      </button>
    );
  };

  return (
    <TooltipProvider>
    <div className="flex flex-col items-center gap-6">
      {/* Category selector */}
      <div className="w-full max-w-md">
        <label className="font-body text-sm font-semibold text-foreground mb-2 block">Select Category</label>
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value as CategoryType)}
          className="w-full rounded-md border border-input bg-background px-3 py-2 font-body text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
        >
          {(Object.keys(categories) as CategoryType[]).map((cat) => (
            <option key={cat} value={cat}>{categories[cat].label}</option>
          ))}
        </select>
      </div>

      {/* Interactive Pokemon Card */}
      <div
        ref={cardRef}
        className={`relative overflow-hidden rounded-2xl border-[3px] ${config.border} shadow-xl w-full max-w-md`}
        style={{ background: config.gradient }}
      >
        {/* Top banner */}
        <div className={`flex items-center justify-between px-4 py-2 ${config.banner}`}>
          <span className="font-display text-xs font-bold text-white uppercase tracking-wider opacity-90">
            {config.typeLabel}
          </span>
          <div className="flex items-center gap-1.5 rounded-full bg-black/25 px-2 py-0.5">
            <Icon size={12} className="text-white" />
            {editingField === 'year' ? (
              <input
                autoFocus
                type="number"
                value={year}
                onChange={(e) => setYear(e.target.value)}
                onBlur={() => setEditingField(null)}
                onKeyDown={(e) => { if (e.key === 'Enter') setEditingField(null); }}
                placeholder="Year"
                className="w-[70px] rounded bg-white/20 px-1.5 py-0.5 font-body text-xs font-bold text-white placeholder:text-white/60 uppercase tracking-wider focus:outline-none focus:ring-1 focus:ring-white/60"
              />
            ) : (
              <button
                type="button"
                onClick={() => setEditingField('year')}
                className="font-display text-xs font-bold text-white uppercase tracking-wider hover:bg-white/10 rounded px-1 transition-colors"
              >
                {year || <span className="opacity-70">Year</span>}
              </button>
            )}
            <FieldHelp text={HELP_TEXT.year} />
          </div>
        </div>

        {/* Image frame */}
        <div className={`mx-3 mt-3 overflow-hidden rounded-lg border-2 ${config.imgBorder} bg-muted relative`}>
          {imageUrl ? (
            <img src={imageUrl} alt={label || 'Preview'} className="w-full h-48 object-cover bg-white" />
          ) : (
            <button
              onClick={() => setEditingField('imageUrl')}
              className="flex flex-col items-center justify-center w-full h-48 text-muted-foreground/40 hover:text-muted-foreground/60 hover:bg-muted/80 transition-colors"
            >
              <Icon size={48} />
              <span className="font-body text-xs mt-2">Click to add image URL</span>
            </button>
          )}
          <div className="absolute top-1.5 right-1.5 rounded-full bg-background/80 backdrop-blur p-1">
            <FieldHelp text={HELP_TEXT.image} />
          </div>
        </div>

        {editingField === 'imageUrl' && (
          <div className="mx-3 mt-2 flex items-center gap-1">
            <input
              autoFocus
              type="url"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') setEditingField(null); }}
              placeholder="https://example.com/image.png"
              className="w-full rounded border border-input bg-background px-2 py-1 font-body text-xs focus:outline-none focus:ring-1 focus:ring-ring"
            />
            <button onClick={() => setEditingField(null)} className="rounded p-0.5 hover:bg-muted"><Check size={12} /></button>
          </div>
        )}

        {/* Scholar (theory only) */}
        {category === 'theory' && (
          <div className="mx-3 mt-1 px-1 flex items-center gap-1">
            <EditableText
              field="scholar"
              value={scholar}
              setValue={setScholar}
              placeholder="Scholar Name (click to edit)"
              className="font-body text-[10px] font-semibold text-theory uppercase tracking-wider"
            />
            <FieldHelp text={HELP_TEXT.scholar} />
          </div>
        )}

        {/* Name plate */}
        <div className={`mx-3 mt-1 rounded-lg ${config.namePlate} px-3 py-1.5 flex items-center gap-1`}>
          <div className="flex-1">
            <EditableText
              field="label"
              value={label}
              setValue={setLabel}
              placeholder="Name (click to edit)"
              className="font-display font-bold text-foreground text-lg"
            />
          </div>
          <FieldHelp text={HELP_TEXT.label} />
        </div>

        {/* Brief */}
        <div className="mx-3 mt-2 px-1 flex items-start gap-1">
          <div className="flex-1">
            <EditableText
              field="brief"
              value={brief}
              setValue={setBrief}
              placeholder="Brief description (click to edit)"
              className="font-body text-sm text-foreground/80 leading-relaxed"
            />
          </div>
          <div className="pt-1.5"><FieldHelp text={HELP_TEXT.brief} /></div>
        </div>

        {/* Detail */}
        <div className="mx-3 mt-1 px-1 flex items-start gap-1">
          <div className="flex-1">
            <EditableText
              field="detail"
              value={detail}
              setValue={setDetail}
              placeholder="Detailed description (click to edit)"
              className="font-body text-xs text-foreground/60 leading-relaxed"
              multiline
            />
          </div>
          <div className="pt-1.5"><FieldHelp text={HELP_TEXT.detail} /></div>
        </div>

        {/* Related — click to open dropdown of existing timeline items */}
        <div ref={relatedBoxRef} className="mx-3 mt-3 rounded-lg border border-border bg-card/60 p-2.5">
          <button
            onClick={() => setShowRelatedDropdown((p) => !p)}
            className="w-full flex items-center justify-between"
          >
            <div className="flex items-center gap-1.5">
              <p className="font-body text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">
                Related
              </p>
              <FieldHelp text={HELP_TEXT.related} />
            </div>
            <Pencil size={10} className="text-muted-foreground/40" />
          </button>

          {selectedTags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-1.5">
              {selectedTags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-body text-[10px] font-semibold border border-border bg-muted text-foreground/70"
                >
                  {tag}
                  <button onClick={() => toggleTag(tag)} className="hover:text-foreground"><X size={8} /></button>
                </span>
              ))}
            </div>
          )}

          {showRelatedDropdown && (
            <div className="mt-2">
              <div className="max-h-40 overflow-y-auto rounded border border-border bg-background p-1">
                {allTimelineLabels.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => toggleTag(item)}
                    onMouseEnter={(e) => {
                      const r = e.currentTarget.getBoundingClientRect();
                      const cardRect = cardRef.current?.getBoundingClientRect();
                      const relatedRect = relatedBoxRef.current?.getBoundingClientRect();
                      const MINI_W = 288; // w-72
                      const left = cardRect ? cardRect.right - MINI_W / 2 : r.right + 12;
                      const bottom = relatedRect ? window.innerHeight - relatedRect.bottom : 0;
                      setHoveredRelated(item);
                      setHoverPos({ bottom, left });
                    }}
                    onMouseLeave={() => setHoveredRelated((curr) => (curr === item ? null : curr))}
                    className={`w-full text-left px-2 py-1 rounded font-body text-xs transition-colors ${
                      selectedTags.includes(item)
                        ? 'bg-primary/10 text-foreground font-semibold'
                        : 'text-foreground/70 hover:bg-muted'
                    }`}
                  >
                    {selectedTags.includes(item) ? '✓ ' : ''}{item}
                  </button>
                ))}
              </div>

              {hoveredRelated && itemsByLabel.get(hoveredRelated) && typeof document !== 'undefined' && createPortal(
                <div
                  className="hidden md:block fixed z-[9999] pointer-events-none"
                  style={{ bottom: hoverPos.bottom, left: hoverPos.left }}
                >
                  <MiniPokemonCard item={itemsByLabel.get(hoveredRelated)!} />
                </div>,
                document.body
              )}
            </div>
          )}
        </div>

        {/* Key Research */}
        <div className="mx-3 mt-2 mb-3 rounded-lg border border-border bg-card/60 p-2.5">
          <div className="flex items-center gap-1.5 mb-1">
            <p className="font-body text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Key Research</p>
            <FieldHelp text={HELP_TEXT.academic} />
          </div>
          <EditableText
            field="academicLabel"
            value={academicLabel}
            setValue={setAcademicLabel}
            placeholder="Citation (click to edit)"
            className="font-body text-xs text-foreground/70"
          />
          <EditableText
            field="academicUrl"
            value={academicUrl}
            setValue={setAcademicUrl}
            placeholder="Article URL (click to edit)"
            className="font-body text-[10px] text-muted-foreground"
          />
        </div>

        {/* Bottom bar */}
        <div className={`h-1.5 ${config.bottomBar}`} />
      </div>

      {/* Submit */}
      <button
        onClick={handleSubmit}
        className="inline-flex items-center gap-2 rounded-lg bg-penn-blue px-5 py-2.5 font-body text-sm font-semibold text-primary-foreground hover:opacity-90 transition-opacity"
      >
        <Plus size={16} />
        Add to Timeline
      </button>
      <p className="font-body text-xs text-muted-foreground -mt-3">
        Only the Name is required — feel free to leave optional fields blank.
      </p>
    </div>
    </TooltipProvider>
  );
}
