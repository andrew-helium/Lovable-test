## Hero refresh — cream background + official PAPI copy

### Visual changes (`src/pages/Index.tsx` — `<header>`)
- Swap the dark navy background (`bg-[#011F5B]`) for soft cream `#FBF7F1`.
- Title (`PennAI Pedagogy Initiative`) → Penn Blue `#011F5B`, italic subtitle → Penn Red `#990000`.
- Subtitle eyebrow line ("University of Pennsylvania • Penn AI • Graduate School of Education") and its dashes → Penn Red `#990000`.
- Body paragraph text → dark slate `#1F2937` for AAA contrast on cream.
- Venn diagram halo: switch radial gradient to a soft warm-white glow that blends with cream (instead of the white halo intended for navy).
- Link pills ("Our Lab's Newsletter", "About PAPI"): navy border + navy text on transparent, hover → navy fill / cream text.
- Scroll-cue chevron → Penn Blue at ~70% opacity.
- Dot-grid background pattern → very subtle navy at ~4% opacity (still visible on cream).
- Footer is untouched (stays Penn Blue).

### Copy changes (hero paragraph)
Replace the existing "EdTech Retrofitting Trap" paragraph with the official PAPI summary, lightly trimmed to fit the hero:

> The **Penn AI Pedagogy Initiative (PAPI)** addresses a key institutional challenge: as universities invest in faculty development and digital capacity, innovative pedagogy adoption stays limited to early adopters. PAPI establishes a structured methodology that directly involves faculty and students in co-designing, testing, and evaluating AI-enhanced pedagogical practices.
>
> **At the heart of our project: AI in education must be co-constructed, not imposed.**

Keep the eyebrow line, title, italic subtitle, venn diagram, link pills, and scroll cue. No other sections (timeline, list view, submission form, footer) change.

### Accessibility notes
- Cream `#FBF7F1` + Penn Blue `#011F5B` text → contrast ratio ~15:1 (AAA).
- Penn Red `#990000` on cream → ~9.6:1 (AAA for body, AA-large for accents).
- Slate `#1F2937` body on cream → ~14:1 (AAA).

### Out of scope
- No changes to the timeline, tutorial, list view, submission form, or footer.
- No changes to the existing intro animation or Venn PNG asset.
- No memory updates yet — will update `mem://style/branding` after you approve, since this flips the hero away from "Penn Blue bg".
